## jaybird-full-2.2.3.jar:
* jdbc f�r firebird
* geh�rt auch zum Auslieferumfang

## servlet-api-2.5.jar:
* Serverlt-Api f�r Tomcat
* wird nur ben�tigt um das Projekt in Eclipse lauf�hig zu halten
* geh�rt NICHT zum Auslieferumfang, wird automatisch von Studio zur Auslieferung hinzu gef�gt    