
package com.zabonlinedb.data.output;



/**
 * Generated for query "getLookupContactPartnerByTenant" on 12/22/2013 00:52:26
 * 
 */
public class GetLookupContactPartnerByTenantRtnType {

    private Integer personId;
    private String contactPartner;
    private String firstName;
    private String name1;
    private String phoneFmt;
    private String email;

    public Integer getPersonId() {
        return personId;
    }

    public void setPersonId(Integer personId) {
        this.personId = personId;
    }

    public String getContactPartner() {
        return contactPartner;
    }

    public void setContactPartner(String contactPartner) {
        this.contactPartner = contactPartner;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getName1() {
        return name1;
    }

    public void setName1(String name1) {
        this.name1 = name1;
    }

    public String getPhoneFmt() {
        return phoneFmt;
    }

    public void setPhoneFmt(String phoneFmt) {
        this.phoneFmt = phoneFmt;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
