
package com.zabonlinedb.data.output;



/**
 * Generated for query "getLookupPersonByMarriage" on 12/22/2013 00:52:26
 * 
 */
public class GetLookupPersonByMarriageRtnType {

    private String marriage_partner;
    private String name1;
    private String firstname;
    private Integer id;

    public String getMarriage_partner() {
        return marriage_partner;
    }

    public void setMarriage_partner(String marriage_partner) {
        this.marriage_partner = marriage_partner;
    }

    public String getName1() {
        return name1;
    }

    public void setName1(String name1) {
        this.name1 = name1;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

}
