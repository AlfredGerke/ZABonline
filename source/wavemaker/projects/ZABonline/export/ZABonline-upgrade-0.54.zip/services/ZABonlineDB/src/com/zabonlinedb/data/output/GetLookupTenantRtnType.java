
package com.zabonlinedb.data.output;



/**
 * Generated for query "getLookupTenant" on 12/22/2013 00:52:26
 * 
 */
public class GetLookupTenantRtnType {

    private Integer pk;
    private String caption;
    private String description;

    public Integer getPk() {
        return pk;
    }

    public void setPk(Integer pk) {
        this.pk = pk;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
