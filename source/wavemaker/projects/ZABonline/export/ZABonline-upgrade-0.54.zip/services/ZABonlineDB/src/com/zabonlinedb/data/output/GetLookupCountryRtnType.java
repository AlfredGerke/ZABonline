
package com.zabonlinedb.data.output;



/**
 * Generated for query "getLookupCountry" on 12/22/2013 00:52:26
 * 
 */
public class GetLookupCountryRtnType {

    private String countryCode;
    private Integer id;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

}
