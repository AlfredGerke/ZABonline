
package com.zabonlinedb.data;



/**
 *  ZABonlineDB.Registry
 *  12/11/2013 23:29:34
 * 
 */
public class Registry {

    private RegistryId id;

    public RegistryId getId() {
        return id;
    }

    public void setId(RegistryId id) {
        this.id = id;
    }

}
