
package com.zabonlinedb.data.output;



/**
 * Generated for query "getLookupPersonByTenant" on 12/22/2013 00:52:26
 * 
 */
public class GetLookupPersonByTenantRtnType {

    private Integer personId;
    private String nameFirstname;
    private String firstName;
    private String name1;
    private String email;

    public Integer getPersonId() {
        return personId;
    }

    public void setPersonId(Integer personId) {
        this.personId = personId;
    }

    public String getNameFirstname() {
        return nameFirstname;
    }

    public void setNameFirstname(String nameFirstname) {
        this.nameFirstname = nameFirstname;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getName1() {
        return name1;
    }

    public void setName1(String name1) {
        this.name1 = name1;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
