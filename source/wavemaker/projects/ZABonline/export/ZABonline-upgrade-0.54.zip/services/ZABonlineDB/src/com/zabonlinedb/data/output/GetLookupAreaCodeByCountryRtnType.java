
package com.zabonlinedb.data.output;



/**
 * Generated for query "getLookupAreaCodeByCountry" on 12/22/2013 00:52:26
 * 
 */
public class GetLookupAreaCodeByCountryRtnType {

    private String caption;

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

}
