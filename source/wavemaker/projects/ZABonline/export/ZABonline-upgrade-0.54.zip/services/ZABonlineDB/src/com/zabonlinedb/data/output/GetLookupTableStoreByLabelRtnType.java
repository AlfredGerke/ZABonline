
package com.zabonlinedb.data.output;



/**
 * Generated for query "getLookupTableStoreByLabel" on 12/22/2013 00:52:26
 * 
 */
public class GetLookupTableStoreByLabelRtnType {

    private String tableName;
    private Integer id;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

}
