
package com.zabonlinedb.data.output;



/**
 * Generated for query "getLookupTitelByCountry" on 12/22/2013 00:52:26
 * 
 */
public class GetLookupTitelByCountryRtnType {

    private String caption;
    private Integer id;

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

}
