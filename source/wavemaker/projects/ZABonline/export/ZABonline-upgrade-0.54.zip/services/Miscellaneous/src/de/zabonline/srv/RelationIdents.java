/**
 *  Erweiterung der von Wavemaker erstellten Javasourcen
 * 
 *  1.0.0 Build 1
 *  
 *  2013-03-26
 *  
 *  Copyright by Alfred Gerke
 */
package de.zabonline.srv;

/**
 * Idents f�r die Zuordnung von Processen
 * 
 * @author Alfred
 * 
 * @version 1.0.0 Build 1
 * 
 */
public enum RelationIdents {
  UNKNOWN,
  BY_PERSON
}
