/**
 *  Erweiterung der von Wavemaker erstellten Javasourcen
 * 
 *  1.0.0 Build 1
 *  
 *  2013-03-30
 *  
 *  Copyright by Alfred Gerke
 */
package de.zabonline.srv;

/**
 * Verwendungszweck f�r Dateiquellen
 * 
 * @author Alfred
 * 
 * @version 1.0.0 Build 1
 *
 */
public enum ResourcePurpose {
  UNKNOWN,
  MEMBERPHOTO
}
