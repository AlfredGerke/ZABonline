dojo.declare("NewProcess", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
_end: 0
});

NewProcess.widgets = {
lbxMain: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}]
};

NewProcess.prototype._cssText = '';
NewProcess.prototype._htmlText = '';