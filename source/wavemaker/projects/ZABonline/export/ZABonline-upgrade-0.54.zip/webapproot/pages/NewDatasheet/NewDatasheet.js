dojo.declare("NewDatasheet", wm.Page, {
    start: function() {

    },
    "preferredDevice": "desktop",

    _end: 0
});