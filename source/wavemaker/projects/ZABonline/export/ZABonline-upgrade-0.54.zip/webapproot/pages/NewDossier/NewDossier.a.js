dojo.declare("NewDossier", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
_end: 0
});

NewDossier.widgets = {
lbxMain: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}]
};

NewDossier.prototype._cssText = '';
NewDossier.prototype._htmlText = '';