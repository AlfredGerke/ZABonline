dojo.declare("AdminByAccordion", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
_end: 0
});

AdminByAccordion.widgets = {
lbxMain: ["wm.Layout", {"horizontalAlign":"center","verticalAlign":"top"}, {}, {
picAddressBook: ["wm.Picture", {"_classes":{"domNode":["imgByAccording"]},"border":"1","borderColor":"","height":"64px","imageIndex":0,"source":"resources/images/buttons/ByAdminInAccordion/tables_64x64.png","width":"64px"}, {}],
lblStructure: ["wm.Label", {"_classes":{"domNode":["lblByAccordion"]},"align":"center","autoSizeWidth":true,"caption":"Struktur","margin":"4","padding":"","width":"57px"}, {}]
}]
};

AdminByAccordion.prototype._cssText = '';
AdminByAccordion.prototype._htmlText = '';