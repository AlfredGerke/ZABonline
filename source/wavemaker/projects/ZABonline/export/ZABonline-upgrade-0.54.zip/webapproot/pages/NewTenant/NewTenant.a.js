dojo.declare("NewTenant", wm.Page, {
"i18n": true,
"preferredDevice": "desktop",
onResultByNewRedording: function() {},
onSuccessByNewRecording: function(success) {},
start: function() {
try {
console.debug('start: start');
app.dlgLoading.setParameter(app.dummyServiceVar, this.wizNewTenant);
this.controller = new NewTenantCtrl(app, this);
console.debug('start: end');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".start() failed: " + e.toString(), e);
}
},
btnFindFactoryDatasheetClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1001, mode: 0, find: 'table_store', label: 'FACTORY_DATA', callback: 'onGetResultBySearch'}");
},
btnFindPersonDatasheetClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1001, mode: 0, find: 'table_store', label: 'PERSON_DATA', callback: 'onGetResultBySearch'}");
},
btnFindContactDatasheetClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1001, mode: 0, find: 'table_store', label: 'CONTACT_DATA', callback: 'onGetResultBySearch'}");
},
btnFindAddressDatasheetClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1001, mode: 0, find: 'table_store', label: 'ADDRESS_DATA', callback: 'onGetResultBySearch'}");
},
btnFindAreaCodeClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000, mode: 0, find: 'country', callback: 'onGetResultBySearch'}");
},
refreshCountryCode: function() {
app.toastInfo("Länderkennungen aktualisieren!");
},
btnAddAreaCodeClick: function(inSender) {
try {
// hier wird der Katalog für die Länderkennung für eine Neuaufnahme geöffenet: Code kommt noch
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".btnAddAreaCodeClick() failed: " + e.toString(), e);
}
},
refreshTable: function() {
app.toastInfo("Verknüpfungen für Tabellen aktualisieren!");
},
btnAddFactoryDatasheetClick: function(inSender) {
try {
app.controller.showWizard("NewTable", "Neuaufnahme Tabelle", true, this, "refreshTable", "init-role-as-subdialog");
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".btnAddAreaCodeClick() failed: " + e.toString(), e);
}
},
btnAddPersonDatasheetClick: function(inSender) {
try {
app.controller.showWizard("NewTable", "Neuaufnahme Tabelle", true, this, "refreshTable", "init-role-as-subdialog");
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".btnAddAreaCodeClick() failed: " + e.toString(), e);
}
},
btnAddContactDatasheetClick: function(inSender) {
try {
app.controller.showWizard("NewTable", "Neuaufnahme Tabelle", true, this, "refreshTable", "init-role-as-subdialog");
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".btnAddAreaCodeClick() failed: " + e.toString(), e);
}
},
btnAddAddressDatasheetClick: function(inSender) {
try {
app.controller.showWizard("NewTable", "Neuaufnahme Tabelle", true, this, "refreshTable", "init-role-as-subdialog");
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".btnAddAreaCodeClick() failed: " + e.toString(), e);
}
},
wizNewTenantCancelClick: function(inSender) {
try {
app.closeWizard();
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".wizNewTenantCancelClick() failed: " + e.toString(), e);
}
},
onShow: function() {
try {
console.debug('onShow: start');
if (!this.controller) {
app.alert(this.getDictionaryItem("ERROR_MSG_BY_UNKNOWN_CONTROLLER"));
app.closeWizard();
} else {
app.dummyServiceVar.doRequest();
if (!this.controller.clearWizard(0)) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_CLEARWIZARD");
}
if (!this.controller.loadLookupData()) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_LOOUPDATA");
}
app.dummyServiceVar.doResult();
}
console.debug('onShow: end');
} catch (e) {
app.dummyServiceVar.doResult();
this.controller.handleExceptionByCtrl(this.name + ".onShow() failed: " + e.toString(), e, 1);
app.closeWizard();
}
},
onStart: function(inPage) {
try {
console.debug('onStart: Begin');
console.debug('onStart: End');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".onStart() failed: " + e.toString(), e);
}
},
wizNewTenantCanchange: function(inSender, inChangeInfo) {
var success = this.controller.onWizNewTenantCanChange(inSender, inChangeInfo);
},
wizNewTenantDoneClick: function(inSender) {
try {
app.closeWizard(this.getDictionaryItem("CONFIRMATION_DO_CLOSE_ADD"), this.getDictionaryItem("CONFIRMATION_DLG_TITLE_FOR_CLOSE_ADD"));
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".wizNewTenantDoneClick() failed: " + e.toString(), e);
}
},
btnAddDataClick: function(inSender) {
try {
console.debug('Start btnAddDataClick');
app.dlgLoading.setParameter(this.addTenant, this.wizNewTenant);
if (this.addTenant.canUpdate()) {
this.addTenant.update();
} else {
app.toastError(this.getDictionaryItem("ERROR_MSG_ADD_TENANT_NO_SUCCESS_BY_EXECUTE"));
}
console.debug('End btnAddDataClick');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".btnAddDataClick() failed: " + e.toString(), e);
}
},
refreshOnaddTenantSuccess: function() {
try {
app.dummyServiceVar.doRequest();
//NavCall wird in clearWizard in selectByLayerIdx ausgeführt
//this.navCallPerson.update();
if (!this.controller.clearWizard(0)) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_CLEARWIZARD");
}
app.dummyServiceVar.doResult();
return true;
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".refreshOnAddTenantSuccess() failed: " + e.toString(), e, -1);
app.dummyServiceVar.doResult();
return false;
}
},
addTenantError: function(inSender, inError) {
try {
console.debug('Start addTenantError');
var errMsg = this.getDictionaryItem("ERROR_MSG_ERROR_BY_ADDTENANT") + inError.message;
app.toastError(errMsg);
console.debug('End addTenantError');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".addTenantError() failed: " + e.toString(), e);
}
},
addTenantResult: function(inSender, inDeprecated) {
try {
console.debug('Start addTenantResult');
console.debug('End addTenantResult');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".addTenantResult() failed: " + e.toString(), e);
}
},
addTenantSuccess: function(inSender, inDeprecated) {
try {
console.debug('Start addTenantSuccess');
/* varResultByInsert muss von dem Aufruf des Serverice gefüllt werden */
console.debug('Success: ' + this.varResultByInsert.getValue('success'));
console.debug('Code: ' + this.varResultByInsert.getValue('code'));
console.debug('Info: ' + this.varResultByInsert.getValue('info'));
var code = this.varResultByInsert.getValue('code');
var success = this.varResultByInsert.getValue('success');
if (!code) {
this.controller.infoByUnhandledCode(success);
} else {
var codeStr = this.varResultByInsert.getValue('info');
if (!codeStr) {
this.controller.infoByUnhandledCode(success);
} else {
var kindFound = codeStr.search(/kind/);
if (kindFound != -1) {
var codeObj = dojo.fromJson(codeStr);
switch (codeObj.kind) {
case 1:
/* Fehler mit einfacher Fehlermeldung */
dojo.publish(codeObj.publish, [codeObj]);
//
break;
case 2:
/* Fehler mit erweiterter Fehlermeldung */
dojo.publish(codeObj.publish, [codeObj]);
//
break;
case 4:
// case 4 und case 3 sollen den selben Code durchlaufen, daher kein code und kein break
case 3:
/* Daten erfolgreich übernommen */
dojo.publish(codeObj.publish, [codeObj]);
if (!this.refreshOnaddTenantSuccess()) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_REFRESHWIZARD");
}
//
break;
default:
//
break;
}
console.debug('Kind: ' + codeObj.kind + ' - Publish: ' + codeObj.publish + ' - Message: ' + codeObj.message);
} else {
this.controller.infoByUnhandledCode(success);
}
}
}
console.debug('End addTenantSuccess');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".addTenantSuccess() failed: " + e.toString(), e);
}
},
onEscapeKey: function() {
try {
app.closeWizard();
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".onEscapeKey() failed: " + e.toString(), e);
}
},
wizNewTenantChange: function(inSender, inIndex) {
try {
switch (inIndex) {
case 1:
break;
case 2:
break;
case 3:
this.controller.setSummeryInfo();
break;
}
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".wizNewTenantChange() failed: " + e.toString(), e);
}
},
tsLookupAddressDataSuccess: function(inSender, inDeprecated) {
try {
console.debug('tsLookupAddressData.getPageCount: ' + this.tsLookupAddressData.getPageCount());
console.debug('tsLookupAddressData.getTotal: ' + this.tsLookupAddressData.getTotal());
console.debug('tsLookupAddressData.getCount: ' + this.tsLookupAddressData.getCount());
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".tsLookupAddressDataSuccess() failed: " + e.toString(), e);
}
},
tsLookupContactDataSuccess: function(inSender, inDeprecated) {
try {
console.debug('tsLookupContactData.getPageCount: ' + this.tsLookupContactData.getPageCount());
console.debug('tsLookupContactData.getTotal: ' + this.tsLookupContactData.getTotal());
console.debug('tsLookupContactData.getCount: ' + this.tsLookupContactData.getCount());
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".tsLookupContactDataSuccess() failed: " + e.toString(), e);
}
},
tsLookupFactoryDataSuccess: function(inSender, inDeprecated) {
try {
console.debug('tsLookupFactoryData.getPageCount: ' + this.tsLookupFactoryData.getPageCount());
console.debug('tsLookupFactoryData.getTotal: ' + this.tsLookupFactoryData.getTotal());
console.debug('tsLookupFactoryData.getCount: ' + this.tsLookupFactoryData.getCount());
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".tsLookupFactoryDataSuccess() failed: " + e.toString(), e);
}
},
tsLookupPersonDataSuccess: function(inSender, inDeprecated) {
try {
console.debug('tsLookupPersonData.getPageCount: ' + this.tsLookupPersonData.getPageCount());
console.debug('tsLookupPersonData.getTotal: ' + this.tsLookupPersonData.getTotal());
console.debug('tsLookupPersonData.getCount: ' + this.tsLookupPersonData.getCount());
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".tsLookupPersonDataSuccess() failed: " + e.toString(), e);
}
},
_end: 0
});

NewTenant.widgets = {
navCallTenant: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layTenant","targetProperty":"layer"}, {}]
}]
}]
}],
navCallRelated: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layRelated","targetProperty":"layer"}, {}]
}]
}]
}],
navCallSession: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"laySession","targetProperty":"layer"}, {}]
}]
}]
}],
navCallSummery: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"laySummery","targetProperty":"layer"}, {}]
}]
}]
}],
addTenant: ["wm.ServiceVariable", {"inFlightBehavior":"executeLast","operation":"addTenantData","service":"ZABonlineAdminService"}, {"onError":"addTenantError","onResult":"addTenantResult","onSuccess":"addTenantSuccess"}, {
input: ["wm.ServiceInput", {"type":"addTenantDataInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"edtTenantCaption.dataValue","targetProperty":"aCaption"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"edtTenantDesc.dataValue","targetProperty":"aDescription"}, {}],
wire6: ["wm.Wire", {"expression":undefined,"source":"edtSessionIdleTime.dataValue","targetProperty":"aSessionIdletime"}, {}],
wire8: ["wm.Wire", {"expression":undefined,"source":"app.countryLookupData.id","targetProperty":"aCountryCodeId"}, {}],
wire2: ["wm.Wire", {"expression":undefined,"source":"edtSessionLifetime.dataValue","targetProperty":"aSessionLifetime"}, {}],
wire3: ["wm.Wire", {"expression":undefined,"source":"edtMaxAttempt.dataValue","targetProperty":"aMaxAttempt"}, {}],
wire4: ["wm.Wire", {"expression":undefined,"source":"cboAddressDatasheet.dataValue","targetProperty":"aAddressDataSheetId"}, {}],
wire5: ["wm.Wire", {"expression":undefined,"source":"cboContactDatasheet.dataValue","targetProperty":"aContactDataSheetId"}, {}],
wire7: ["wm.Wire", {"expression":undefined,"source":"cboPersonDatasheet.dataValue","targetProperty":"aPersonDataSheetId"}, {}],
wire9: ["wm.Wire", {"expression":undefined,"source":"cboFactoryDatasheet.dataValue","targetProperty":"aFactoryDataSheetId"}, {}]
}]
}]
}],
varResultByInsert: ["wm.Variable", {"isList":true,"type":"de.zabonline.srv.Results.ProcResults"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"addTenant","targetProperty":"dataSet"}, {}]
}]
}],
varTenantId: ["wm.Variable", {"type":"NumberData"}, {}],
tsLookupFactoryData: ["wm.ServiceVariable", {"autoUpdate":true,"inFlightBehavior":"executeLast","operation":"getLookupDataSheetByLabel","service":"ZABonlineDB"}, {"onSuccess":"tsLookupFactoryDataSuccess"}, {
input: ["wm.ServiceInput", {"type":"getLookupDataSheetByLabelInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"FACTORY_DATA\"","targetProperty":"label"}, {}]
}]
}]
}],
tsLookupPersonData: ["wm.ServiceVariable", {"autoUpdate":true,"inFlightBehavior":"executeLast","operation":"getLookupDataSheetByLabel","service":"ZABonlineDB"}, {"onSuccess":"tsLookupPersonDataSuccess"}, {
input: ["wm.ServiceInput", {"type":"getLookupDataSheetByLabelInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"PERSON_DATA\"","targetProperty":"label"}, {}]
}]
}]
}],
tsLookupContactData: ["wm.ServiceVariable", {"autoUpdate":true,"inFlightBehavior":"executeLast","operation":"getLookupDataSheetByLabel","service":"ZABonlineDB"}, {"onSuccess":"tsLookupContactDataSuccess"}, {
input: ["wm.ServiceInput", {"type":"getLookupDataSheetByLabelInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"CONTACT_DATA\"","targetProperty":"label"}, {}]
}]
}]
}],
tsLookupAddressData: ["wm.ServiceVariable", {"autoUpdate":true,"inFlightBehavior":"executeLast","operation":"getLookupDataSheetByLabel","service":"ZABonlineDB"}, {"onSuccess":"tsLookupAddressDataSuccess"}, {
input: ["wm.ServiceInput", {"type":"getLookupDataSheetByLabelInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"ADDRESS_DATA\"","targetProperty":"label"}, {}]
}]
}]
}],
varDSContactData: ["wm.Variable", {"isList":true,"type":"com.zabonlinedb.data.output.GetLookupDataSheetByLabelRtnType"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"tsLookupContactData","targetProperty":"dataSet"}, {}]
}]
}],
varDSAddressData: ["wm.Variable", {"isList":true,"type":"com.zabonlinedb.data.output.GetLookupDataSheetByLabelRtnType"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"tsLookupAddressData","targetProperty":"dataSet"}, {}]
}]
}],
varDSPersonData: ["wm.Variable", {"isList":true,"type":"com.zabonlinedb.data.output.GetLookupDataSheetByLabelRtnType"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"tsLookupPersonData","targetProperty":"dataSet"}, {}]
}]
}],
varDSFactoryData: ["wm.Variable", {"isList":true,"type":"com.zabonlinedb.data.output.GetLookupDataSheetByLabelRtnType"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"tsLookupFactoryData","targetProperty":"dataSet"}, {}]
}]
}],
lbxMain: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top","width":"1427px"}, {}, {
wizNewTenant: ["wm.WizardLayers", {}, {"onCancelClick":"wizNewTenantCancelClick","onDoneClick":"wizNewTenantDoneClick","oncanchange":"wizNewTenantCanchange","onchange":"wizNewTenantChange"}, {
layTenant: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Mandant","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlTenantLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlTenantData: ["wm.FancyPanel", {"title":"Mandant"}, {}, {
edtTenantCaption: ["wm.Text", {"caption":"Manadant","dataValue":undefined,"displayValue":"","required":true}, {}],
edtTenantDesc: ["wm.Text", {"caption":"Beschreibung","dataValue":undefined,"displayValue":"","width":"640px"}, {}]
}]
}]
}],
layRelated: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Zugehörig","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlRelatedLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlRelatedData: ["wm.FancyPanel", {"title":"Verknüpfungen"}, {}, {
cboFactoryDatasheetPanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboFactoryDatasheet: ["wm.SelectMenu", {"allowNone":true,"caption":"Betriebsdaten","dataField":"id","dataType":"com.zabonlinedb.data.output.GetLookupDataSheetByLabelRtnType","dataValue":undefined,"displayField":"caption","displayValue":""}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"varDSFactoryData","targetProperty":"dataSet"}, {}]
}]
}],
btnFindFactoryDatasheet: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindFactoryDatasheetClick"}],
btnAddFactoryDatasheet: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddFactoryDatasheetClick"}]
}],
cboPersonDatasheetPanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboPersonDatasheet: ["wm.SelectMenu", {"allowNone":true,"caption":"Personendaten","dataField":"id","dataType":"com.zabonlinedb.data.output.GetLookupDataSheetByLabelRtnType","dataValue":undefined,"displayField":"caption","displayValue":""}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"varDSPersonData","targetProperty":"dataSet"}, {}]
}]
}],
btnFindPersonDatasheet: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindPersonDatasheetClick"}],
btnAddPersonDatasheet: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddPersonDatasheetClick"}]
}],
cboContactDatasheetPanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboContactDatasheet: ["wm.SelectMenu", {"allowNone":true,"caption":"Kontaktdaten","dataField":"id","dataType":"com.zabonlinedb.data.output.GetLookupDataSheetByLabelRtnType","dataValue":undefined,"displayField":"caption","displayValue":""}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"varDSContactData","targetProperty":"dataSet"}, {}]
}]
}],
btnFindContactDatasheet: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindContactDatasheetClick"}],
btnAddContactDatasheet: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddContactDatasheetClick"}]
}],
cboAddressDatasheetPanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboAddressDatasheet: ["wm.SelectMenu", {"allowNone":true,"caption":"Adressdaten","dataField":"id","dataType":"com.zabonlinedb.data.output.GetLookupDataSheetByLabelRtnType","dataValue":undefined,"displayField":"caption","displayValue":""}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"varDSAddressData","targetProperty":"dataSet"}, {}]
}]
}],
btnFindAddressDatasheet: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindAddressDatasheetClick"}],
btnAddAddressDatasheet: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddAddressDatasheetClick"}]
}]
}]
}]
}],
laySession: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Eigenschaften","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlSessionLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlSessionData: ["wm.FancyPanel", {"title":"Sitzung"}, {}, {
cboAreaCodePanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboAreaCode: ["wm.SelectMenu", {"allowNone":true,"caption":"Länderkennung","dataField":"id","dataType":"com.zabonlinedb.data.output.GetLookupCountryRtnType","dataValue":undefined,"displayField":"countryCode","displayValue":""}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"app.countryCodeData","targetProperty":"dataSet"}, {}]
}]
}],
btnFindAreaCode: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindAreaCodeClick"}],
btnAddAreaCode: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddAreaCodeClick"}]
}],
edtSessionIdleTime: ["wm.Number", {"caption":"Ruhezeit","dataValue":undefined,"displayValue":"","helpText":"Ruhezeit in Minuten","required":true}, {}],
edtSessionLifetime: ["wm.Number", {"caption":"Lebenszeit","dataValue":undefined,"displayValue":"","helpText":"Lebenszeit in Tagen","required":true}, {}],
edtMaxAttempt: ["wm.Number", {"caption":"Vorschläge","dataValue":undefined,"displayValue":"","helpText":"max. Anzahl Suchwortvorschläge","required":true}, {}]
}]
}]
}],
laySummery: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Zusammenfassung","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlSummery: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
pnlSummeryDetailTop: ["wm.Panel", {"height":"90%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlSummeryDetailMandant: ["wm.FancyPanel", {"title":"Mandant","width":"33%"}, {}, {
btnGotoMandant: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallTenant"}],
lblSumInfoMandant: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoDesc: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}],
pnlSummeryDetailRelated: ["wm.FancyPanel", {"title":"Zugehörigkeit","width":"34%"}, {}, {
btnGotoRelated: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallRelated"}],
lblSumInfoFactoryDatasheet: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoPersonDatasheet: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoContactDatasheet: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoAddressDatasheet: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}],
pnlSummeryDetailSession: ["wm.FancyPanel", {"title":"Sitzung","width":"33%"}, {}, {
btnGotoSitzung: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallSession"}],
lblSumInfoAreaCode: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoIdleTime: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoLifetime: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoMaxAttempt: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}]
}],
pnlSummeryDetailBottom: ["wm.Panel", {"height":"10%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
btnAddData: ["wm.Button", {"caption":"Daten aufnehmen","margin":"4","width":"100%"}, {"onclick":"btnAddDataClick"}]
}]
}]
}]
}]
}]
};

NewTenant.prototype._cssText = '';
NewTenant.prototype._htmlText = '';