dojo.declare("NewUser", wm.Page, {
"i18n": true,
"preferredDevice": "desktop",
onResultByNewRedording: function() {},
onSuccessByNewRecording: function(success) {},
createSHA512OnRequireReady: function() {
console.debug('createSHA512OnRequireReady: start');
this.sha512 = new SHA512(0, "=");
console.debug('createSHA512OnRequireReady: end');
},
start: function() {
try {
console.debug('start: start');
app.dlgLoading.setParameter(app.dummyServiceVar, this.wizNewUser);
wm.require("zabonline.crypt.SHA512", true);
this.controller = new NewUserCtrl(app, this);
dojo.ready(this, "createSHA512OnRequireReady");
console.debug('start: end');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".start() failed: " + e.toString(), e);
}
},
wizNewUserCancelClick: function(inSender) {
try {
app.closeWizard();
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".wizNewUserCancelClick() failed: " + e.toString(), e);
}
},
onShow: function() {
try {
console.debug('onShow: start');
if (!this.controller) {
app.alert(this.getDictionaryItem("ERROR_MSG_BY_UNKNOWN_CONTROLLER"));
app.closeWizard();
} else {
app.dummyServiceVar.doRequest();
if (!this.controller.clearWizard(0)) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_CLEARWIZARD");
}
if (!this.controller.loadLookupData()) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_LOOUPDATA");
}
app.dummyServiceVar.doResult();
}
console.debug('onShow: end');
} catch (e) {
app.dummyServiceVar.doResult();
this.controller.handleExceptionByCtrl(this.name + ".onShow() failed: " + e.toString(), e, 1);
app.closeWizard();
}
},
onStart: function(inPage) {
try {
console.debug('onStart: Begin');
console.debug('onStart: End');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".onStart() failed: " + e.toString(), e);
}
},
wizNewUserCanchange: function(inSender, inChangeInfo) {
var success = this.controller.onWizNewUserCanChange(inSender, inChangeInfo);
},
onEscapeKey: function() {
try {
app.closeWizard();
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".onEscapeKey() failed: " + e.toString(), e);
}
},
wizNewUserChange: function(inSender, inIndex) {
try {
switch (inIndex) {
case 1:
break;
case 2:
break;
case 3:
this.controller.setSummeryInfo();
break;
}
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".wizNewUserChange() failed: " + e.toString(), e);
}
},
wizNewUserDoneClick: function(inSender) {
try {
app.closeWizard(this.getDictionaryItem("CONFIRMATION_DO_CLOSE_ADD_USER"), this.getDictionaryItem("CONFIRMATION_DLG_TITLE_FOR_CLOSE_ADDUSER"));
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".wizNewUserDoneClick() failed: " + e.toString(), e);
}
},
refreshPerson: function() {
this.controller.loadPersonLookupData();
},
refreshTenant: function() {
this.controller.loadTenantLookupData();
},
refreshRole: function() {
this.controller.loadRoleLookupData();
},
btnAddPersonClick: function(inSender) {
try {
app.controller.showWizard("NewAddress", "Neuaufnahme Adresse", true, this, "refreshPerson", "init-address-as-subdialog");
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".btnAddPersonClick() failed: " + e.toString(), e);
}
},
btnFindPersonClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000,  mode: 0, find: 'person', callback: 'onGetResultBySearch'}");
},
btnAddMandantClick: function(inSender) {
try {
app.controller.showWizard("NewTenant", "Neuaufnahme Mandant", true, this, "refreshTenant", "init-tenant-as-subdialog");
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".btnAddMandantClick() failed: " + e.toString(), e);
}
},
btnAddRoleClick: function(inSender) {
try {
app.controller.showWizard("NewRole", "Neuaufnahme Rolle", true, this, "refreshRole", "init-role-as-subdialog");
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".btnAddRoleClick() failed: " + e.toString(), e);
}
},
btnFindMandantClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000,  mode: 0, find: 'tenant', callback: 'onGetResultBySearch'}");
},
btnFindRoleClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000,  mode: 0, find: 'role', callback: 'onGetResultBySearch'}");
},
btnAddDataClick: function(inSender) {
try {
console.debug('Start btnAddDataClick');
var pass = this.sha512.hex_sha512(this.edtRepeatPass.getDataValue());
app.dlgLoading.setParameter(this.addUser, this.wizNewUser);
this.addUser.input.setValue('aPassword', pass);
if (this.addUser.canUpdate()) {
this.addUser.update();
} else {
app.toastError(this.getDictionaryItem("ERROR_MSG_ADD_USER_NO_SUCCESS_BY_EXECUTE"));
}
console.debug('End btnAddDataClick');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".btnAddDataClick() failed: " + e.toString(), e);
}
},
addUserResult: function(inSender, inDeprecated) {
try {
console.debug('Start addUserResult');
console.debug('End addUserResult');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".addUserResult() failed: " + e.toString(), e);
}
},
addUserError: function(inSender, inError) {
try {
console.debug('Start addUserError');
var errMsg = this.getDictionaryItem("ERROR_MSG_ERROR_BY_ADDUSER") + inError.message;
app.toastError(errMsg);
console.debug('End addUserError');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".addUserError() failed: " + e.toString(), e);
}
},
refreshOnAddUserSuccess: function() {
try {
app.dummyServiceVar.doRequest();
//NavCall wird in clearWizard in selectByLayerIdx ausgeführt
//this.navCallPerson.update();
if (!this.controller.clearWizard(0)) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_CLEARWIZARD");
}
app.dummyServiceVar.doResult();
return true;
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".refreshOnAddUserSuccess() failed: " + e.toString(), e, -1);
app.dummyServiceVar.doResult();
return false;
}
},
addUserSuccess: function(inSender, inDeprecated) {
try {
console.debug('Start addUserSuccess');
/* varResultByInsert muss von dem Aufruf des Serverice gefüllt werden */
console.debug('Success: ' + this.varResultByInsert.getValue('success'));
console.debug('Code: ' + this.varResultByInsert.getValue('code'));
console.debug('Info: ' + this.varResultByInsert.getValue('info'));
var code = this.varResultByInsert.getValue('code');
var success = this.varResultByInsert.getValue('success');
if (!code) {
this.controller.infoByUnhandledCode(success);
} else {
var codeStr = this.varResultByInsert.getValue('info');
if (!codeStr) {
this.controller.infoByUnhandledCode(success);
} else {
var kindFound = codeStr.search(/kind/);
if (kindFound != -1) {
var codeObj = dojo.fromJson(codeStr);
switch (codeObj.kind) {
case 1:
/* Fehler mit einfacher Fehlermeldung */
dojo.publish(codeObj.publish, [codeObj]);
//
break;
case 2:
/* Fehler mit erweiterter Fehlermeldung */
dojo.publish(codeObj.publish, [codeObj]);
//
break;
case 4:
// case 4 und case 3 sollen den selben Code durchlaufen, daher kein code und kein break
case 3:
/* Daten erfolgreich übernommen */
dojo.publish(codeObj.publish, [codeObj]);
if (!this.refreshOnAddUserSuccess()) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_REFRESHWIZARD");
}
//
break;
default:
//
break;
}
console.debug('Kind: ' + codeObj.kind + ' - Publish: ' + codeObj.publish + ' - Message: ' + codeObj.message);
} else {
this.controller.infoByUnhandledCode(success);
}
}
}
console.debug('End addUserSuccess');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".addUserSuccess() failed: " + e.toString(), e);
}
},
_end: 0
});

NewUser.widgets = {
navCallUser: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layUser","targetProperty":"layer"}, {}]
}]
}]
}],
navCallRelated: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layRelated","targetProperty":"layer"}, {}]
}]
}]
}],
navCallAdmin: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layAdmin","targetProperty":"layer"}, {}]
}]
}]
}],
navCallSummery: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"laySummery","targetProperty":"layer"}, {}]
}]
}]
}],
varTenantId: ["wm.Variable", {"type":"NumberData"}, {}],
tenantLookupVar: ["wm.ServiceVariable", {"inFlightBehavior":"executeLast","maxResults":50,"operation":"getLookupTenant","service":"ZABonlineDB"}, {}, {
input: ["wm.ServiceInput", {"type":"getLookupTenantInputs"}, {}]
}],
roleLookupVar: ["wm.ServiceVariable", {"inFlightBehavior":"executeLast","maxResults":50,"operation":"getLookupRole","service":"ZABonlineDB"}, {}, {
input: ["wm.ServiceInput", {"type":"getLookupRoleInputs"}, {}]
}],
personLookupVar: ["wm.ServiceVariable", {"autoUpdate":true,"inFlightBehavior":"executeLast","maxResults":50,"operation":"getLookupPersonByTenant","service":"ZABonlineDB"}, {}, {
input: ["wm.ServiceInput", {"type":"getLookupPersonByTenantInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"varTenantId.dataValue","targetProperty":"TenantId"}, {}]
}]
}]
}],
addUser: ["wm.ServiceVariable", {"inFlightBehavior":"dontExecute","operation":"addUserData","service":"ZABonlineAdminService"}, {"onError":"addUserError","onResult":"addUserResult","onSuccess":"addUserSuccess"}, {
input: ["wm.ServiceInput", {"type":"addUserDataInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"edtEmail.dataValue","targetProperty":"aEmail"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"cbxAllowLogin.dataValue","targetProperty":"aAllowLogin"}, {}],
wire2: ["wm.Wire", {"expression":undefined,"source":"edtName.dataValue","targetProperty":"aName"}, {}],
wire3: ["wm.Wire", {"expression":undefined,"source":"edtFirstname.dataValue","targetProperty":"aFirstname"}, {}],
wire4: ["wm.Wire", {"expression":undefined,"source":"edtUser.dataValue","targetProperty":"aUsername"}, {}],
wire5: ["wm.Wire", {"expression":undefined,"source":"edtRole.dataValue","targetProperty":"aRoleId"}, {}],
wire6: ["wm.Wire", {"expression":undefined,"source":"edtTenant.dataValue","targetProperty":"aTenantId"}, {}],
wire7: ["wm.Wire", {"expression":undefined,"source":"edtPerson.dataValue","targetProperty":"aPersonId"}, {}]
}]
}]
}],
varResultByInsert: ["wm.Variable", {"isList":true,"type":"de.zabonline.srv.Results.ProcResults"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"addUser","targetProperty":"dataSet"}, {}]
}]
}],
lbxMain: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}, {
wizNewUser: ["wm.WizardLayers", {}, {"onCancelClick":"wizNewUserCancelClick","onDoneClick":"wizNewUserDoneClick","oncanchange":"wizNewUserCanchange","onchange":"wizNewUserChange"}, {
layUser: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Benutzer","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlUserLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
pnlUserData: ["wm.FancyPanel", {"title":"Anmeldedaten"}, {}, {
edtUser: ["wm.Text", {"caption":"Benutzer","dataValue":undefined,"displayValue":"","required":true}, {}],
edtPassword: ["wm.Text", {"caption":"Passwort","dataValue":undefined,"displayValue":"","password":true,"required":true}, {}],
edtRepeatPass: ["wm.Text", {"caption":" ","dataValue":undefined,"displayValue":"","helpText":undefined,"password":true,"placeHolder":undefined}, {}],
edtFirstname: ["wm.Text", {"caption":"Vorname","dataValue":undefined,"displayValue":"","required":true}, {}],
edtName: ["wm.Text", {"caption":"Name","dataValue":undefined,"displayValue":"","required":true}, {}],
edtEmail: ["wm.Text", {"caption":"eMail","dataValue":undefined,"displayValue":"","required":true}, {}]
}]
}]
}],
layRelated: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Zugehörig","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlRelatedLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
pnlRelated: ["wm.FancyPanel", {"styles":{"fontSize":""},"title":"Verknüpfungen"}, {}, {
edtRolePanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
edtRole: ["wm.SelectMenu", {"caption":"Berechtigungen","captionSize":"110px","dataField":"pk","dataType":"com.zabonlinedb.data.output.GetLookupRoleRtnType","displayExpression":"${description}+\", (\"+${caption}+\")\"","displayField":"caption","displayValue":"","emptyValue":"null","required":true}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"roleLookupVar","targetProperty":"dataSet"}, {}]
}]
}],
btnFindRole: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindRoleClick"}],
btnAddRole: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddRoleClick"}]
}],
edtTenantPanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
edtTenant: ["wm.SelectMenu", {"caption":"Mandant","captionSize":"110px","dataField":"pk","dataType":"com.zabonlinedb.data.output.GetLookupTenantRtnType","displayExpression":"${description}+\", (\"+${caption}+\")\"","displayField":"caption","displayValue":"","emptyValue":"null","required":true}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"tenantLookupVar","targetProperty":"dataSet"}, {}]
}]
}],
btnFindTenant: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindMandantClick"}],
btnAddTenant: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddMandantClick"}]
}],
edtPersonPanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
edtPerson: ["wm.SelectMenu", {"caption":"Personendaten","captionSize":"110px","dataField":"personId","dataType":"com.zabonlinedb.data.output.GetLookupPersonByTenantRtnType","displayField":"nameFirstname","displayValue":"","emptyValue":"null"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"personLookupVar","targetProperty":"dataSet"}, {}]
}]
}],
btnFindPerson: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindPersonClick"}],
btnAddPerson: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddPersonClick"}]
}]
}]
}]
}],
layAdmin: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Administration","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlAdminLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
pnlAdmin: ["wm.FancyPanel", {"title":"Administration"}, {}, {
cbxAllowLogin: ["wm.Checkbox", {"caption":"Anmeldung erlauben","captionSize":"130px","displayValue":true,"startChecked":true}, {}]
}]
}]
}],
laySummery: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Zusammenfassung","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlSummery: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
pnlSummeryDetailTop: ["wm.Panel", {"height":"90%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlSummeryDetailLogin: ["wm.FancyPanel", {"title":"Anmeldedaten","width":"33%"}, {}, {
btnGotoLogin: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallUser"}],
lblSumInfoUser: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoFirstname: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoName: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoEmail: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}, {
format: ["wm.DataFormatter", {}, {}]
}]
}],
pnlSummeryDetailRelated: ["wm.FancyPanel", {"title":"Zugehörigkeit","width":"34%"}, {}, {
btnGotoRelated: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallRelated"}],
lblSumInfoRole: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoTenant: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoPerson: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}],
pnlSummeryDetailAdmin: ["wm.FancyPanel", {"title":"Administration","width":"33%"}, {}, {
btnGotoContact: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallAdmin"}],
lblSumInfoAllowLogin: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}]
}],
pnlSummeryDetailBottom: ["wm.Panel", {"height":"10%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
btnAddData: ["wm.Button", {"caption":"Daten aufnehmen","margin":"4","width":"100%"}, {"onclick":"btnAddDataClick"}]
}]
}]
}]
}]
}]
};

NewUser.prototype._cssText = '';
NewUser.prototype._htmlText = '';