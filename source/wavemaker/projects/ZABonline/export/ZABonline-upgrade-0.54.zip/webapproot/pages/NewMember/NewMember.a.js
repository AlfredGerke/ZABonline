dojo.declare("NewMember", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
_end: 0
});

NewMember.widgets = {
layoutBox1: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}]
};

NewMember.prototype._cssText = '';
NewMember.prototype._htmlText = '';