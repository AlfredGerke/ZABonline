dojo.declare("NewAddress", wm.Page, {
"preferredDevice": "desktop",
"i18n": true,
onResultByNewRedording: function() {},
onSuccessByNewRecording: function(success) {},
setDefaultStateByPhotoLayout: function() {
this.picPhoto.setSource('resources/images/logos/symbol_questionmark.png');
this.varUploadPhoto.clearData();
this.varUploadPhotoResponse.clearData();
this.fileUpload.reset();
this.fileUpload.setShowing(false);
this.varFilename.clearData();
this.varUniqueFilename.clearData();
},
start: function() {
try {
console.debug('start: start');
app.dlgLoading.setParameter(app.dummyServiceVar, this.wizNewAddress);
this.controller = new NewAddressCtrl(app, this);
console.debug('start: end');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".start() failed: " + e.toString(), e);
}
},
wizNewAddressCancelClick: function(inSender) {
try {
app.closeWizard();
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".wizNewAddressCancelClick() failed: " + e.toString(), e);
}
},
onShow: function() {
try {
console.debug('onShow: start');
if (!this.controller) {
app.alert(this.getDictionaryItem("ERROR_MSG_BY_UNKNOWN_CONTROLLER"));
app.closeWizard();
} else {
app.dummyServiceVar.doRequest();
if (!this.controller.clearWizard(0)) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_CLEARWIZARD");
}
if (!this.controller.loadLookupData()) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_LOOUPDATA");
}
app.dummyServiceVar.doResult();
}
console.debug('onShow: end');
} catch (e) {
app.dummyServiceVar.doResult();
this.controller.handleExceptionByCtrl(this.name + ".onShow() failed: " + e.toString(), e, 1);
app.closeWizard();
}
},
wizNewAddressCanchange: function(inSender, inChangeInfo) {
var success = this.controller.onWizNewAddressCanChange(inSender, inChangeInfo);
},
onEscapeKey: function() {
try {
app.closeWizard();
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".onEscapeKey() failed: " + e.toString(), e);
}
},
cbxNoInfoChange: function(inSender) {
try {
this.controller.enableContainer(inSender.getChecked(), this.pnlInfoLayout, this.edtDescription);
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cbxNoInfoChange() failed: " + e.toString(), e);
}
},
cbxNoAddressDataChange: function(inSender) {
try {
this.controller.setByQuickSetup("Address", !inSender.getChecked(), true);
//
this.controller.enableContainer(inSender.getChecked(), this.pnlAddressLayout, this.cboAddressType);
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cbxNoAddressDataChange() failed: " + e.toString(), e);
}
},
cbxNoContactDataChange: function(inSender) {
try {
this.controller.setByQuickSetup("Contact", !inSender.getChecked(), true);
//
this.controller.enableContainer(inSender.getChecked(), this.pnlContactLayout, this.cboContactType);
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cbxNoContactDataChange() failed: " + e.toString(), e);
}
},
cbxNoBankInfoChange: function(inSender) {
try {
this.controller.setByQuickSetup("BankInfo", !inSender.getChecked(), true);
//
this.controller.enableContainer(inSender.getChecked(), this.pnlBankLayout, this.edtDepositor);
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cbxNoBankInfoChange() failed: " + e.toString(), e);
}
},
cbxNoPhotoChange: function(inSender) {
try {
this.controller.enableContainer(inSender.getChecked(), this.pnlPhotoLayout);
if (inSender.getChecked()) {
this.setDefaultStateByPhotoLayout();
}
else {
this.fileUpload.setShowing(true);
}
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cbxNoPhotoChange() failed: " + e.toString(), e);
}
},
fileUploadSuccess: function(inSender, fileList) {
try {
var relFilename = this.varUploadPhoto.getValue('path');
var filename = app.utils.extractFilename(relFilename);
this.varFilename.setValue("dataValue", filename);
this.varUniqueFilename.setValue("dataValue", filename); /* Stand 2013-03-22: der Eindeutige Dateiname wird serverseitig ermittelt; an dieser Stelle wird der reale Name übergeben */
console.debug('path: ' + this.varUploadPhoto.getValue('path'));
console.debug('filename: ' + filename);
this.picPhoto.setSource(this.varUploadPhoto.getValue('path'));
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".fileUploadSuccess() failed: " + e.toString(), e);
}
},
cboSalutationChange: function(inSender) {
try {
var desc = app.utils.getPropertyValue(inSender.selectedItem.getData(), "description");
if (desc !== null) {
this.edtAltSalutation.setDataValue(desc);
}
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cboSalutationChange() failed: " + e.toString(), e);
}
},
cboMarrigePartnerIdChange: function(inSender) {
try {
var data = inSender.selectedItem.getData();
if (data) {
var firstName = app.utils.getPropertyValue(data, "firstname");
if (firstName !== null) {
this.edtMarrigePartnerFirstName.setDataValue(firstName);
}
//
var name1 = app.utils.getPropertyValue(data, "name1");
if (name1 !== null) {
this.edtMarrigePartnerName.setDataValue(name1);
}
}
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cboMarrigePartnerIdChange() failed: " + e.toString(), e);
}
},
cbxIsMarriedChange: function(inSender) {
try {
this.controller.setByQuickSetup("Person", inSender.getChecked(), true);
//
this.pnlMarriagePartnerData.setDisabled(!inSender.getChecked());
if (!inSender.getChecked()) {
this.pnlMarriagePartnerData.clearData();
}
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cbxIsMarriedChange() failed: " + e.toString(), e);
}
},
marriagePartnerLookupDataSuccess: function(inSender, inDeprecated) {
try {
console.debug('marriagePartnerLookupData.getPageCount: ' + this.marriagePartnerLookupData.getPageCount());
console.debug('marriagePartnerLookupData.getTotal: ' + this.marriagePartnerLookupData.getTotal());
console.debug('marriagePartnerLookupData.getCount: ' + this.marriagePartnerLookupData.getCount());
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".marriagePartnerLookupDataSuccess() failed: " + e.toString(), e);
}
},
startTestProcVar: function(inSender) {
try {
app.dlgLoading.setParameter(this.testProcVar, this.wizNewAddress);
//this.testProcVar.input.setValue('aDate', null);
this.testProcVar.input.setValue('aInteger', 1808);
this.testProcVar.input.setValue('aSmallInt', 254);
this.testProcVar.input.setValue('aTenantId', app.globalData.tenantId());
this.testProcVar.input.setValue('aVarchar254', "absdef");
this.testProcVar.input.setValue('aVarchar2000', "absdefghijklmnopqrstuvw");
if (this.testProcVar.canUpdate()) {
this.testProcVar.update();
}
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".startTestProcVar() failed: " + e.toString(), e);
}
},
testProcVarError: function(inSender, inError) {
try {
console.debug(inSender);
console.debug(inError);
var errMsg = this.getDictionaryItem("ERROR_MSG_ERROR_BY_ADD_ADDERSSBOOKITEM") + inError.message;
app.toastError(errMsg);
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".testProcVarError() failed: " + e.toString(), e);
}
},
testProcVarSuccess: function(inSender, inDeprecated) {
try {
console.debug(inSender);
console.debug(inDeprecated);
console.debug('SessionId: ' + app.getSessionId());
console.debug('Success: ' + this.varResultByInsert.getValue('success'));
console.debug('Code: ' + this.varResultByInsert.getValue('code'));
console.debug('Info: ' + this.varResultByInsert.getValue('info'));
var codeStr = this.varResultByInsert.getValue('info');
var codeObj = dojo.fromJson(codeStr);
console.debug('Name: ' + codeObj[0].name + ' - Vorname: ' + codeObj[0].vorname + ' - Id: ' + codeObj[0].id);
console.debug('Name: ' + codeObj[1].name + ' - Vorname: ' + codeObj[1].vorname + ' - Id: ' + codeObj[1].id);
console.debug('Name: ' + codeObj[2].name + ' - Vorname: ' + codeObj[2].vorname + ' - Id: ' + codeObj[2].id);
this.varCodeByResult.setJson("[{name: 'five', dataValue: 5}, {name: 'three', dataValue: 3}]");
console.debug(this.varCodeByResult.getData());
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".testProcVarSuccess() failed: " + e.toString(), e);
}
},
testProcVarResult: function(inSender, inDeprecated) {
try {
console.debug(inSender.getData());
console.debug('success: ' + inDeprecated.success);
console.debug('code: ' + inDeprecated.code);
console.debug('info: ' + inDeprecated.info);
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".testProcVarResult() failed: " + e.toString(), e);
}
},
wizNewAddressChange: function(inSender, inIndex) {
try {
switch (inIndex) {
case 1:
break;
case 2:
break;
case 3:
break;
case 4:
break;
case 5:
break;
case 6:
this.controller.setSummeryInfo();
break;
}
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".wizNewAddressChange() failed: " + e.toString(), e);
}
},
btnAddAddressBookItemClick: function(inSender) {
try {
console.debug('Start btnAddAddressBookItemClick');
app.dlgLoading.setParameter(this.addAddressBookItem, this.wizNewAddress);
if (this.addAddressBookItem.canUpdate()) {
this.addAddressBookItem.update();
} else {
app.toastError(this.getDictionaryItem("ERROR_MSG_ADD_ADDRESSBOOKITEM_NO_SUCCESS_BY_EXECUTE"));
}
console.debug('End btnAddAddressBookItemClick');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".btnAddAddressBookItemClick() failed: " + e.toString(), e);
}
},
addAddressBookItemResult: function(inSender, inDeprecated) {
try {
console.debug('Start addAddressBookItemResult');
console.debug('End addAddressBookItemResult');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".addAddressBookItemResult() failed: " + e.toString(), e);
}
},
refreshMarriagePartnerLookupData: function() {
try {
if (this.marriagePartnerLookupData.canUpdate()) {
this.marriagePartnerLookupData.update();
} else {
throw this.getDictionaryItem("ERROR_MSG_BY_REFRESH_MARRIAGEPARTNER_LOOKUP_DATA");
}
return true;
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".refreshMarriagePartnerLookupData() failed: " + e.toString(), e, -1);
return false;
}
},
refreshOnAddAddressBookItemSuccess: function() {
try {
app.dummyServiceVar.doRequest();
//NavCall wird in clearWizard in selectByLayerIdx ausgeführt
//this.navCallPerson.update();
if (!this.controller.clearWizard(0)) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_CLEARWIZARD");
}
this.refreshMarriagePartnerLookupData();
//if (this.marriagePartnerLookupData.canUpdate()) {
//    this.marriagePartnerLookupData.update();
//} else {
//    throw this.getDictionaryItem("ERROR_MSG_BY_REFRESH_MARRIAGEPARTNER_LOOKUP_DATA");
//}
app.dummyServiceVar.doResult();
return true;
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".refreshOnAddAddressBookItemSuccess() failed: " + e.toString(), e, -1);
app.dummyServiceVar.doResult();
return false;
}
},
addAddressBookItemSuccess: function(inSender, inDeprecated) {
try {
console.debug('Start addAddressBookItemSuccess');
/* varResultByInsert muss von dem Aufruf der Testprocedure auf den AddAddressBoolItem-Service umgelegt werden */
console.debug('Success: ' + this.varResultByInsert.getValue('success'));
console.debug('Code: ' + this.varResultByInsert.getValue('code'));
console.debug('Info: ' + this.varResultByInsert.getValue('info'));
var code = this.varResultByInsert.getValue('code');
var success = this.varResultByInsert.getValue('success');
if (!code) {
this.controller.infoByUnhandledCode(success);
} else {
var codeStr = this.varResultByInsert.getValue('info');
if (!codeStr) {
this.controller.infoByUnhandledCode(success);
} else {
var kindFound = codeStr.search(/kind/);
if (kindFound != -1) {
var codeObj = dojo.fromJson(codeStr);
switch (codeObj.kind) {
case 1:
/* Fehler mit einfacher Fehlermeldung */
dojo.publish(codeObj.publish, [codeObj]);
//
break;
case 2:
/* Fehler mit erweiterter Fehlermeldung */
dojo.publish(codeObj.publish, [codeObj]);
//
break;
case 4:
// case 4 und case 3 sollen den selben Code durchlaufen, daher kein code und kein break
case 3:
/* Daten erfolgreich übernommen */
dojo.publish(codeObj.publish, [codeObj]);
if (!this.refreshOnAddAddressBookItemSuccess()) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_REFRESHWIZARD");
}
//
break;
default:
//
break;
}
console.debug('Kind: ' + codeObj.kind + ' - Publish: ' + codeObj.publish + ' - Message: ' + codeObj.message);
} else {
this.controller.infoByUnhandledCode(success);
}
}
}
console.debug('End addAddressBookItemSuccess');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".addAddressBookItemSuccess() failed: " + e.toString(), e);
}
},
addAddressBookItemError: function(inSender, inError) {
try {
console.debug('Start addAddressBookItemError');
var errMsg = this.getDictionaryItem("ERROR_MSG_ERROR_BY_ADD_ADDERSSBOOKITEM") + inError.message;
app.toastError(errMsg);
console.debug('End addAddressBookItemError');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".addAddressBookItemError() failed: " + e.toString(), e);
}
},
onStart: function(inPage) {
try {
console.debug('onStart: Begin');
console.debug('onStart: End');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".onStart() failed: " + e.toString(), e);
}
},
wizNewAddressDoneClick: function(inSender) {
try {
app.closeWizard(this.getDictionaryItem("CONFIRMATION_DO_CLOSE_ADD_ADDRESBOOKITEM"), this.getDictionaryItem("CONFIRMATION_DLG_TITLE_FOR_CLOSE_ADDRESBOOKITEM"));
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".wizNewAddressDoneClick() failed: " + e.toString(), e);
}
},
onGetResultBySearch: function() {},
btnFindSalutationClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000, mode: 0, find: 'salutation', callback: 'onGetResultBySearch'}");
},
refreshByAddCatalogItem: function() {
return function(scope, catalog) {
scope.controller.onRefreshLookupByTarget(catalog, 1);
};
},
btnAddSalutationClick: function(inSender) {
this.controller.showCatalogItem(this, "{kind: 1001, mode: 0, page: 'NewCatalogItem', catalog: 'SALUTATION'}", this.refreshByAddCatalogItem(), app.getDictionaryItem("CAPTION_ADDCATALOG_TITLE_SALUTATION"));
},
btnFindTitelClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000,  mode: 0, find: 'titel', callback: 'onGetResultBySearch'}");
},
btnAddTitelClick: function(inSender) {
this.controller.showCatalogItem(this, "{kind: 1001, mode: 0, page: 'NewCatalogItem', catalog: 'TITEL'}", this.refreshByAddCatalogItem(), app.getDictionaryItem("CAPTION_ADDCATALOG_TITLE_TITLE"));
},
btnFindPersonClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000,  mode: 0, find: 'person', callback: 'onGetResultBySearch'}");
},
refreshPerson: function() {
this.refreshMarriagePartnerLookupData();
},
btnAddPersonClick: function(inSender) {
try {
app.controller.showWizard("NewAddress", "Neuaufnahme Adresse", true, this, "refreshPerson", "init-address-as-subdialog");
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".btnAddPersonClick() failed: " + e.toString(), e);
}
},
btnFindAddressTypeClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000,  mode: 0, find: 'addressType', callback: 'onGetResultBySearch'}");
},
btnAddAddressTypeClick: function(inSender) {
this.controller.showCatalogItem(this, "{kind: 1001, mode: 0, page: 'NewCatalogItem', catalog: 'ADDRESS_TYPE'}", this.refreshByAddCatalogItem(), app.getDictionaryItem("CAPTION_ADDCATALOG_TITLE_ADDRESS_TYPE"));
},
btnFindContactTypeClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000,  mode: 0, find: 'contactType', callback: 'onGetResultBySearch'}");
},
btnAddContactTypeClick: function(inSender) {
this.controller.showCatalogItem(this, "{kind: 1001, mode: 0, page: 'NewCatalogItem', catalog: 'CONTACT_TYPE'}", this.refreshByAddCatalogItem(), app.getDictionaryItem("CAPTION_ADDCATALOG_TITLE_CONTACT_TYPE"));
},
btnFindAreaCodeClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000,  mode: 0, find: 'areaCode', callback: 'onGetResultBySearch'}");
},
btnAddAreaCodeClick: function(inSender) {
this.controller.showCatalogItem(this, "{kind: 1001, mode: 0, page: 'NewCatalogItem', catalog: 'AREA_CODE'}", this.refreshByAddCatalogItem(), app.getDictionaryItem("CAPTION_ADDCATALOG_TITLE_AREA_CODE"));
},
_end: 0
});

NewAddress.widgets = {
varUploadPhoto: ["wm.Variable", {"type":"FileUploadDownload.WMFile"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"fileUpload.variable.name","targetProperty":"name"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"fileUpload.variable.path","targetProperty":"path"}, {}]
}]
}],
varUploadPhotoResponse: ["wm.Variable", {"type":"com.wavemaker.runtime.server.FileUploadResponse"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"fileUpload.variable.error","targetProperty":"error"}, {}]
}]
}],
marriagePartnerLookupData: ["wm.ServiceVariable", {"autoUpdate":true,"inFlightBehavior":"dontExecute","loadingDialog":"","operation":"getLookupPersonByMarriage","service":"ZABonlineDB"}, {"onSuccess":"marriagePartnerLookupDataSuccess"}, {
input: ["wm.ServiceInput", {"type":"getLookupPersonByMarriageInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"1","targetProperty":"married"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"varTenantId.dataValue","targetProperty":"TenantId"}, {}]
}]
}]
}],
varTenantId: ["wm.Variable", {"type":"NumberData"}, {}],
testProcVar: ["wm.ServiceVariable", {"inFlightBehavior":"dontExecute","operation":"testProc","service":"addressBookService"}, {"onError":"testProcVarError","onResult":"testProcVarResult","onSuccess":"testProcVarSuccess"}, {
input: ["wm.ServiceInput", {"type":"testProcInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"edtBirthday.dataValue","targetProperty":"aDate"}, {}]
}]
}]
}],
varResultByInsert: ["wm.Variable", {"isList":true,"type":"de.zabonline.srv.Results.ProcResults"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"addAddressBookItem","targetProperty":"dataSet"}, {}]
}]
}],
varCodeByResult: ["wm.Variable", {"isList":true,"json":"[\n\t{\n\t\t\"name\": \"Gerke\", \n\t\t\"dataValue\": \"Alfred\"\n\t}, \n\t{\n\t\t\"name\": \"Gerke2\", \n\t\t\"dataValue\": \"Alfred2\"\n\t}, \n\t{\n\t\t\"name\": \"Gerke3\", \n\t\t\"dataValue\": \"Alfred3\"\n\t}\n]","type":"EntryData"}, {}],
navCallPerson: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"layPerson","targetProperty":"layer"}, {}]
}]
}]
}],
navCallAddress: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"layAddress","targetProperty":"layer"}, {}]
}]
}]
}],
navCallContact: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"layContact","targetProperty":"layer"}, {}]
}]
}]
}],
navCallBank: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"layBank","targetProperty":"layer"}, {}]
}]
}]
}],
addAddressBookItem: ["wm.ServiceVariable", {"inFlightBehavior":"dontExecute","operation":"addAddressBookItem","service":"addressBookService"}, {"onError":"addAddressBookItemError","onResult":"addAddressBookItemResult","onSuccess":"addAddressBookItemSuccess"}, {
input: ["wm.ServiceInput", {"type":"addAddressBookItemInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"edtBirthday.dataValue","targetProperty":"aDayOfBirth"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"edtMarriedSince.dataValue","targetProperty":"aMarriedSince"}, {}],
wire2: ["wm.Wire", {"expression":"!${cbxNoAddressData.dataValue}","source":false,"targetProperty":"aAddressDataPresent"}, {}],
wire3: ["wm.Wire", {"expression":undefined,"source":"cboAddressType.dataValue","targetProperty":"aAddressTypeId"}, {}],
wire4: ["wm.Wire", {"expression":undefined,"source":"edtAltSalutation.dataValue","targetProperty":"aAltsalutation"}, {}],
wire5: ["wm.Wire", {"expression":undefined,"source":"cboAreaCode.dataValue","targetProperty":"aAreaCode"}, {}],
wire6: ["wm.Wire", {"expression":undefined,"source":"edtBIC.dataValue","targetProperty":"aBIC"}, {}],
wire7: ["wm.Wire", {"expression":"!${cbxNoBankInfo.dataValue}","source":false,"targetProperty":"aBankDataPresent"}, {}],
wire8: ["wm.Wire", {"expression":undefined,"source":"edtBLZ.dataValue","targetProperty":"aBlzFmt"}, {}],
wire9: ["wm.Wire", {"expression":undefined,"source":"edtCity.dataValue","targetProperty":"aCity"}, {}],
wire10: ["wm.Wire", {"expression":"!${cbxNoContactData.dataValue}","source":false,"targetProperty":"aContactDataPresent"}, {}],
wire11: ["wm.Wire", {"expression":undefined,"source":"cboContactType.dataValue","targetProperty":"aContactTypeId"}, {}],
wire12: ["wm.Wire", {"expression":undefined,"source":"edtDepositor.dataValue","targetProperty":"aDepositor"}, {}],
wire13: ["wm.Wire", {"expression":undefined,"source":"edtDistrict.dataValue","targetProperty":"aDistrict"}, {}],
wire14: ["wm.Wire", {"expression":undefined,"source":"edtEmail.dataValue","targetProperty":"aEmail"}, {}],
wire15: ["wm.Wire", {"expression":undefined,"source":"edtFax.dataValue","targetProperty":"aFaxFmt"}, {}],
wire16: ["wm.Wire", {"expression":undefined,"source":"edtFirstName.dataValue","targetProperty":"aFirstName"}, {}],
wire17: ["wm.Wire", {"expression":undefined,"source":"edtIBAN.dataValue","targetProperty":"aIBAN"}, {}],
wire18: ["wm.Wire", {"expression":undefined,"source":"edtDescription.dataValue","targetProperty":"aInfo"}, {}],
wire19: ["wm.Wire", {"expression":"!${cbxNoInfo.dataValue}","source":false,"targetProperty":"aInfoDataPresent"}, {}],
wire20: ["wm.Wire", {"expression":undefined,"source":"cbxIsMarried.dataValue","targetProperty":"aIsMarried"}, {}],
wire21: ["wm.Wire", {"expression":undefined,"source":"cbxIsPostOfficeAddress.dataValue","targetProperty":"aIsPostAddress"}, {}],
wire22: ["wm.Wire", {"expression":undefined,"source":"cbxIsPrivateAddress.dataValue","targetProperty":"aIsPrivateAddress"}, {}],
wire23: ["wm.Wire", {"expression":undefined,"source":"cbxIsPrivate.dataValue","targetProperty":"aIsPrivatePerson"}, {}],
wire24: ["wm.Wire", {"expression":undefined,"source":"edtKTO.dataValue","targetProperty":"aKtoFmt"}, {}],
wire25: ["wm.Wire", {"expression":undefined,"source":"edtMarrigePartnerFirstName.dataValue","targetProperty":"aMarriagePartnerFirstName"}, {}],
wire26: ["wm.Wire", {"expression":undefined,"source":"edtMarrigePartnerName.dataValue","targetProperty":"aMarriagePartnerName1"}, {}],
wire27: ["wm.Wire", {"expression":undefined,"source":"cboMarrigePartnerId.dataValue","targetProperty":"aMarriedToId"}, {}],
wire28: ["wm.Wire", {"expression":undefined,"source":"edtMessanger.dataValue","targetProperty":"aMessangerName"}, {}],
wire29: ["wm.Wire", {"expression":undefined,"source":"edtName1.dataValue","targetProperty":"aName"}, {}],
wire30: ["wm.Wire", {"expression":undefined,"source":"edtName2.dataValue","targetProperty":"aName2"}, {}],
wire31: ["wm.Wire", {"expression":undefined,"source":"edtTel.dataValue","targetProperty":"aPhoneFmt"}, {}],
wire32: ["wm.Wire", {"expression":"!${cbxNoPhoto.dataValue}","source":false,"targetProperty":"aPhotoPresent"}, {}],
wire33: ["wm.Wire", {"expression":undefined,"source":"edtPostOffice.dataValue","targetProperty":"aPostOfficeBox"}, {}],
wire34: ["wm.Wire", {"expression":undefined,"source":"cboSalutation.dataValue","targetProperty":"aSalutationId"}, {}],
wire35: ["wm.Wire", {"expression":undefined,"source":"edtSkype.dataValue","targetProperty":"aSkype"}, {}],
wire36: ["wm.Wire", {"expression":undefined,"source":"edtStreet.dataValue","targetProperty":"aStreet"}, {}],
wire37: ["wm.Wire", {"expression":undefined,"source":"edtStreetAddressFrom.dataValue","targetProperty":"aStreetAddressFrom"}, {}],
wire38: ["wm.Wire", {"expression":undefined,"source":"edtStreetAddressTo.dataValue","targetProperty":"aStreetAddressTo"}, {}],
wire39: ["wm.Wire", {"expression":undefined,"source":"cboTitel.dataValue","targetProperty":"aTitelId"}, {}],
wire40: ["wm.Wire", {"expression":undefined,"source":"edtWWW.dataValue","targetProperty":"aWWW"}, {}],
wire41: ["wm.Wire", {"expression":undefined,"source":"edtZIPCode.dataValue","targetProperty":"aZipcode"}, {}],
wire42: ["wm.Wire", {"expression":undefined,"source":"varFilename.dataValue","targetProperty":"aPhotoRealName"}, {}],
wire43: ["wm.Wire", {"expression":undefined,"source":"varTenantId.dataValue","targetProperty":"aTenantId"}, {}]
}]
}]
}],
navCallInfo: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layInfo","targetProperty":"layer"}, {}]
}]
}]
}],
navCallPhoto: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layPhoto","targetProperty":"layer"}, {}]
}]
}]
}],
navCallSummery: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"laySummery","targetProperty":"layer"}, {}]
}]
}]
}],
varFilename: ["wm.Variable", {"type":"StringData"}, {}],
varUniqueFilename: ["wm.Variable", {"type":"StringData"}, {}],
lbxMain: ["wm.Layout", {"autoScroll":false,"horizontalAlign":"left","verticalAlign":"top","width":"1274px"}, {}, {
wizNewAddress: ["wm.WizardLayers", {"defaultLayer":0}, {"onCancelClick":"wizNewAddressCancelClick","onDoneClick":"wizNewAddressDoneClick","oncanchange":"wizNewAddressCanchange","onchange":"wizNewAddressChange"}, {
layPerson: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Personendaten","horizontalAlign":"left","padding":"5","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlPersonLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
pnlBasicData: ["wm.FancyPanel", {"height":"239px","innerLayoutKind":"left-to-right","title":"Person"}, {}, {
pnlBasisData: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
cboSalutationPanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboSalutation: ["wm.SelectMenu", {"caption":"Anrede","captionSize":"120px","dataField":"id","dataType":"com.zabonlinedb.data.output.GetLookupSalutationByCountryRtnType","displayField":"caption","displayValue":""}, {"onchange":"cboSalutationChange"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"app.salutationData","targetProperty":"dataSet"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"app.salutationData.id","targetProperty":"dataValue"}, {}]
}]
}],
btnFindSalutation: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindSalutationClick"}],
btnAddSalutation: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddSalutationClick"}]
}],
edtAltSalutation: ["wm.Text", {"caption":"alternative Anrede","captionSize":"120px","dataValue":undefined,"displayValue":""}, {}],
cboTitelPanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboTitel: ["wm.SelectMenu", {"caption":"Titel","captionSize":"120px","dataField":"id","dataType":"com.zabonlinedb.data.output.GetLookupTitelByCountryRtnType","displayField":"caption","displayValue":""}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"app.titelData","targetProperty":"dataSet"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"app.titelData.id","targetProperty":"dataValue"}, {}]
}]
}],
btnFindTitel: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindTitelClick"}],
btnAddTitel: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddTitelClick"}]
}],
edtFirstName: ["wm.Text", {"caption":"Vorname","captionSize":"120px","dataValue":undefined,"displayValue":""}, {}],
edtName1: ["wm.Text", {"caption":"Name","captionSize":"120px","dataValue":undefined,"displayValue":"","required":true}, {}],
edtName2: ["wm.Text", {"caption":"Name 2","captionSize":"120px","dataValue":undefined,"displayValue":""}, {}],
edtBirthday: ["wm.Date", {"caption":"Geburtstag","captionSize":"120px","dataValue":undefined,"displayValue":""}, {}],
cbxIsPrivate: ["wm.Checkbox", {"caption":"Privat","captionSize":"120px","displayValue":false,"emptyValue":"false","width":"140px"}, {}]
}]
}],
pnlMarriagePartner: ["wm.FancyPanel", {"title":"Ehepartner"}, {}, {
cbxIsMarried: ["wm.Checkbox", {"caption":"verheiratet","displayValue":false,"emptyValue":"false"}, {"onchange":"cbxIsMarriedChange"}],
pnlMarriagePartnerData: ["wm.Panel", {"disabled":true,"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
edtMarriedSince: ["wm.Date", {"caption":"verheiratet seit","dataValue":undefined,"displayValue":""}, {}],
cboMarrigePartnerIdPanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboMarrigePartnerId: ["wm.SelectMenu", {"allowNone":true,"caption":"Ehepartner","dataField":"id","dataType":"com.zabonlinedb.data.output.GetLookupPersonByMarriageRtnType","dataValue":undefined,"displayField":"marriage_partner","displayValue":"","emptyValue":"null"}, {"onchange":"cboMarrigePartnerIdChange"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"marriagePartnerLookupData","targetProperty":"dataSet"}, {}]
}]
}],
btnFindPerson: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindPersonClick"}],
btnAddPerson: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddPersonClick"}]
}],
edtMarrigePartnerFirstName: ["wm.Text", {"caption":"Vorname","dataValue":"","displayValue":"","emptyValue":"emptyString"}, {}],
edtMarrigePartnerName: ["wm.Text", {"caption":"Name","dataValue":"","displayValue":"","emptyValue":"emptyString","required":true}, {}]
}]
}]
}]
}],
layAddress: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Adressdaten","horizontalAlign":"left","margin":"5","padding":"5","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlNoAddressData: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
cbxNoAddressData: ["wm.Checkbox", {"caption":"keine Adressdaten","captionAlign":"left","captionPosition":"right","captionSize":"150px","displayValue":false,"emptyValue":"false","height":"100%","width":"150px"}, {"onchange":"cbxNoAddressDataChange"}]
}],
pnlAddressLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlBasicAddressData: ["wm.FancyPanel", {"freeze":false,"title":"Adresse"}, {}, {
cboAddressTypePanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboAddressType: ["wm.SelectMenu", {"caption":"Addresstyp","dataField":"id","dataType":"com.zabonlinedb.data.output.GetLookupAddressTypeByCountryRtnType","displayField":"caption","displayValue":""}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"app.addressTypeData","targetProperty":"dataSet"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"app.addressTypeData.id","targetProperty":"dataValue"}, {}]
}]
}],
btnFindAddressType: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindAddressTypeClick"}],
btnAddAddressType: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddAddressTypeClick"}]
}],
edtDistrict: ["wm.Text", {"caption":"Ortsteil","dataValue":undefined,"displayValue":""}, {}],
pnlFmtCityData: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
edtZIPCode: ["wm.Text", {"caption":"PLZ","dataValue":undefined,"displayValue":"","regExp":"","required":true,"width":"178px"}, {}],
edtCity: ["wm.Text", {"caption":"Stadt","captionSize":"50px","dataValue":undefined,"displayValue":"","required":true,"width":"221px"}, {}]
}],
edtPostOffice: ["wm.Text", {"caption":"Postfach","dataValue":undefined,"displayValue":""}, {}],
pnlFmtStreetData: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
edtStreet: ["wm.Text", {"caption":"Straße","dataValue":undefined,"displayValue":"","required":true}, {}],
edtStreetAddressFrom: ["wm.Text", {"caption":"von","captionSize":"50px","dataValue":undefined,"displayValue":"","required":true,"width":"100px"}, {}],
edtStreetAddressTo: ["wm.Text", {"caption":"bis","captionSize":"50px","dataValue":undefined,"displayValue":"","width":"100px"}, {}]
}],
cbxIsPostOfficeAddress: ["wm.Checkbox", {"caption":"Postanschrift","displayValue":false,"emptyValue":"false"}, {}],
cbxIsPrivateAddress: ["wm.Checkbox", {"caption":"Privat","displayValue":false,"emptyValue":"false"}, {}]
}]
}]
}],
layContact: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Kontaktdaten","horizontalAlign":"left","margin":"5","padding":"5","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlNoContactData: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
cbxNoContactData: ["wm.Checkbox", {"caption":"keine Kontaktdaten","captionAlign":"left","captionPosition":"right","captionSize":"150px","displayValue":false,"emptyValue":"false","height":"100%","width":"150px"}, {"onchange":"cbxNoContactDataChange"}]
}],
pnlContactLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlBasicContactData: ["wm.FancyPanel", {"title":"Kontakt"}, {}, {
cboContactTypePanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboContactType: ["wm.SelectMenu", {"caption":"Kontakttyp","dataField":"id","dataType":"com.zabonlinedb.data.output.GetLookupContactTypeByCountryRtnType","displayField":"caption","displayValue":""}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"app.contactTypeData","targetProperty":"dataSet"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"app.contactTypeData.id","targetProperty":"dataValue"}, {}]
}]
}],
btnFindContactType: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindContactTypeClick"}],
btnAddContactType: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddContactTypeClick"}]
}],
cboAreaCodePanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboAreaCode: ["wm.SelectMenu", {"allowNone":true,"caption":"Ländervorwahl","dataField":"caption","dataType":"com.zabonlinedb.data.output.GetLookupAreaCodeByCountryRtnType","displayField":"caption","displayValue":""}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"app.areaCodeData","targetProperty":"dataSet"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"app.areaCodeData.areacode","targetProperty":"dataValue"}, {}]
}]
}],
btnFindAreaCode: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindAreaCodeClick"}],
btnAddAreaCode: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddAreaCodeClick"}]
}],
edtTel: ["wm.Text", {"caption":"Telefon","dataValue":undefined,"displayValue":""}, {}],
edtFax: ["wm.Text", {"caption":"Fax","dataValue":undefined,"displayValue":""}, {}],
edtWWW: ["wm.Text", {"caption":"www","dataValue":undefined,"displayValue":""}, {}],
edtEmail: ["wm.Text", {"caption":"eMail","dataValue":undefined,"displayValue":""}, {}],
edtSkype: ["wm.Text", {"caption":"Skype","dataValue":undefined,"displayValue":""}, {}],
edtMessanger: ["wm.Text", {"caption":"Messanger","dataValue":undefined,"displayValue":""}, {}]
}]
}]
}],
layBank: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Bankinformationen","horizontalAlign":"left","margin":"5","padding":"5","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlNoBankInfo: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
cbxNoBankInfo: ["wm.Checkbox", {"caption":"keine Bankinformationen","captionAlign":"left","captionPosition":"right","captionSize":"170px","displayValue":false,"emptyValue":"false","height":"100%","width":"170px"}, {"onchange":"cbxNoBankInfoChange"}]
}],
pnlBankLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlBasicBankData: ["wm.FancyPanel", {"title":"Bank"}, {}, {
edtDepositor: ["wm.Text", {"caption":"Kontoinhaber","dataValue":undefined,"displayValue":"","required":true}, {}],
edtKTO: ["wm.Text", {"caption":"Kontonummer","dataValue":undefined,"displayValue":"","required":true}, {}],
edtBLZ: ["wm.Text", {"caption":"Bankleitzahl","dataValue":undefined,"displayValue":"","required":true}, {}],
edtIBAN: ["wm.Text", {"caption":"IBAN","dataValue":undefined,"displayValue":""}, {}],
edtBIC: ["wm.Text", {"caption":"BIC","dataValue":undefined,"displayValue":""}, {}]
}]
}]
}],
layInfo: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Information","horizontalAlign":"left","margin":"5","padding":"5","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlNoInfo: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
cbxNoInfo: ["wm.Checkbox", {"caption":"keine Informationen","captionAlign":"left","captionPosition":"right","captionSize":"170px","displayValue":false,"emptyValue":"false","height":"100%","width":"170px"}, {"onchange":"cbxNoInfoChange"}]
}],
pnlInfoLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlFreeText: ["wm.FancyPanel", {"title":"Freitext"}, {}, {
edtDescription: ["wm.RichText", {"height":"100%"}, {}]
}]
}]
}],
layPhoto: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Foto","horizontalAlign":"left","margin":"5","padding":"5","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlNoPhoto: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
cbxNoPhoto: ["wm.Checkbox", {"caption":"keine Foto","captionAlign":"left","captionPosition":"right","captionSize":"170px","displayValue":false,"emptyValue":"false","height":"100%","width":"170px"}, {"onchange":"cbxNoPhotoChange"}]
}],
pnlPhotoLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlChoosePhoto: ["wm.FancyPanel", {"innerHorizontalAlign":"center","title":"Fotodatei auswählen"}, {}, {
picPhoto: ["wm.Picture", {"aspect":"v","height":"217px","margin":"5,0,0,0","source":"resources/images/logos/symbol_questionmark.png","width":"155px"}, {}],
fileUpload: ["wm.DojoFileUpload", {"buttonCaption":"Laden...","height":"30px","layoutKind":"top-to-bottom","padding":"5,0,0,0","useList":false,"width":"159px"}, {"onSuccess":"fileUploadSuccess"}, {
input: ["wm.ServiceInput", {"type":"uploadFileInputs"}, {}]
}],
lblPhotoName: ["wm.Label", {"margin":"5,0,0,0","padding":"4","width":"159px"}, {}, {
format: ["wm.DataFormatter", {}, {}],
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"Datei: \" + ${varFilename.dataValue}","targetProperty":"caption"}, {}]
}]
}],
lblResponseInfo: ["wm.Label", {"_classes":{"domNode":["wm_FontColor_BrightRed"]},"height":"84px","padding":"4","singleLine":false,"width":"159px"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"varUploadPhotoResponse.error","targetProperty":"caption"}, {}]
}]
}]
}]
}]
}],
laySummery: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Zusammenfassen","horizontalAlign":"left","margin":"5","padding":"5","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlSummery: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
pnlSummeryDetailTop: ["wm.Panel", {"height":"90%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlSummeryDetailPerson: ["wm.FancyPanel", {"title":"Person","width":"25%"}, {}, {
btnGotoPerson: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallPerson"}],
lblSumInfoSalutation: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoAltSalutation: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoTitel: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}, {
format: ["wm.DataFormatter", {}, {}]
}],
lblSumInfoFirstName: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoName: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoName2: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoBirthday: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoIsPrivat: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoIsMarried: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoMarriedSince: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoPartnerFirstName: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoPartnerName: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}],
pnlSummeryDetailAddress: ["wm.FancyPanel", {"title":"Adresse","width":"25%"}, {}, {
btnGotoAddress: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallAddress"}],
lblSumInfoAddressType: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoDistrict: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoZIPCode: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoCity: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoPostOffice: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoStreet: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoStreetAddressFrom: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoStreetAddressTo: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoIsPostOfficeAddress: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfosPrivateAddress: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}],
pnlSummeryDetailContact: ["wm.FancyPanel", {"title":"Kontakt","width":"25%"}, {}, {
btnGotoContact: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallContact"}],
lblSumInfoContactType: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoAreaCode: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoTel: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoFax: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoWWW: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoEmail: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoSkype: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoMessanger: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}],
pnlSummeryDetailBank: ["wm.FancyPanel", {"title":"Bank","width":"25%"}, {}, {
btnGotoBank: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallBank"}],
lblSumInfoDepositor: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoKTO: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoBLZ: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoIBAN: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoBIC: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}]
}],
pnlSummeryDetailBottom: ["wm.Panel", {"height":"10%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
btnAddAddressBookItem: ["wm.Button", {"caption":"Daten aufnehmen","margin":"4","width":"100%"}, {"onclick":"btnAddAddressBookItemClick"}]
}]
}]
}]
}]
}]
};

NewAddress.prototype._cssText = '';
NewAddress.prototype._htmlText = '';