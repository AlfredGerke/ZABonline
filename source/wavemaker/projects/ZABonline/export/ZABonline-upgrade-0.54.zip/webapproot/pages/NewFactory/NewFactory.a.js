dojo.declare("NewFactory", wm.Page, {
"i18n": true,
"preferredDevice": "desktop",
start: function() {
try {
console.debug('start: start');
app.dlgLoading.setParameter(app.dummyServiceVar, this.wizNewFactory);
this.controller = new NewFactoryCtrl(app, this);
console.debug('start: end');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".start() failed: " + e.toString(), e);
}
},
onShow: function() {
try {
console.debug('onShow: start');
if (!this.controller) {
app.alert(this.getDictionaryItem("ERROR_MSG_BY_UNKNOWN_CONTROLLER"));
app.closeWizard();
} else {
app.dummyServiceVar.doRequest();
if (!this.controller.clearWizard(0)) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_CLEARWIZARD");
}
if (!this.controller.loadLookupData()) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_LOOUPDATA");
}
app.dummyServiceVar.doResult();
}
console.debug('onShow: end');
} catch (e) {
app.dummyServiceVar.doResult();
this.controller.handleExceptionByCtrl(this.name + ".onShow() failed: " + e.toString(), e, 1);
app.closeWizard();
}
},
wizNewFactoryCancelClick: function(inSender) {
try {
app.closeWizard();
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".wizNewFactoryCancelClick() failed: " + e.toString(), e);
}
},
wizNewFactoryChange: function(inSender, inIndex) {
try {
switch (inIndex) {
case 1:
break;
case 2:
break;
case 3:
break;
case 4:
break;
case 5:
break;
case 6:
break;
case 7:
this.controller.setSummeryInfo();
break;
}
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".wizNewAddressChange() failed: " + e.toString(), e);
}
},
wizNewFactoryDoneClick: function(inSender) {
try {
app.closeWizard(this.getDictionaryItem("CONFIRMATION_DO_CLOSE_ADD_FACTORYITEM"), this.getDictionaryItem("CONFIRMATION_DLG_TITLE_FOR_CLOSE_FACTORYITEM"));
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".wizNewFactoryDoneClick() failed: " + e.toString(), e);
}
},
onStart: function(inPage) {
try {
console.debug('onStart: Begin');
console.debug('onStart: End');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".onStart() failed: " + e.toString(), e);
}
},
wizNewFactoryCanchange: function(inSender, inChangeInfo) {
var success = this.controller.onWizNewFactoryCanChange(inSender, inChangeInfo);
},
onEscapeKey: function() {
try {
app.closeWizard();
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".onEscapeKey() failed: " + e.toString(), e);
}
},
cbxNoInfoChange: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
this.controller.enableContainer(inSender.getChecked(), this.pnlInfoLayout, this.edtDescription);
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cbxNoInfoChange() failed: " + e.toString(), e);
}
},
cbxNoAddressDataChange: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
this.controller.setByQuickSetup("Address", !inSender.getChecked(), true);
//
this.controller.enableContainer(inSender.getChecked(), this.pnlAddressLayout, this.cboAddressType);
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cbxNoAddressDataChange() failed: " + e.toString(), e);
}
},
cbxNoContactDataChange: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
this.controller.setByQuickSetup("Contact", !inSender.getChecked(), true);
//
this.controller.enableContainer(inSender.getChecked(), this.pnlContactLayout, this.cboContactType);
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cbxNoContactDataChange() failed: " + e.toString(), e);
}
},
cbxNoBankInfoChange: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
this.controller.setByQuickSetup("BankInfo", !inSender.getChecked(), true);
//
this.controller.enableContainer(inSender.getChecked(), this.pnlBankLayout, this.edtDepositor);
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cbxNoBankInfoChange() failed: " + e.toString(), e);
}
},
cbxNoPhotoChange: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
this.controller.enableContainer(inSender.getChecked(), this.pnlPhotoLayout);
if (inSender.getChecked()) {
this.setDefaultStateByPhotoLayout();
}
else {
this.fileUpload.setShowing(true);
}
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cbxNoPhotoChange() failed: " + e.toString(), e);
}
},
setDefaultStateByPhotoLayout: function() {
this.picPhoto.setSource('resources/images/logos/symbol_questionmark.png');
this.varUploadPhoto.clearData();
this.varUploadPhotoResponse.clearData();
this.fileUpload.reset();
this.fileUpload.setShowing(false);
this.varFilename.clearData();
this.varUniqueFilename.clearData();
},
fileUploadSuccess: function(inSender, fileList) {
try {
var relFilename = this.varUploadPhoto.getValue('path');
var filename = app.utils.extractFilename(relFilename);
this.varFilename.setValue("dataValue", filename);
this.varUniqueFilename.setValue("dataValue", filename); /* Stand 2013-03-22: der Eindeutige Dateiname wird serverseitig ermittelt; an dieser Stelle wird der reale Name übergeben */
console.debug('path: ' + this.varUploadPhoto.getValue('path'));
console.debug('filename: ' + filename);
this.picPhoto.setSource(this.varUploadPhoto.getValue('path'));
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".fileUploadSuccess() failed: " + e.toString(), e);
}
},
cboContactPartnerIdChange: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
var data = inSender.selectedItem.getData();
if (data) {
var firstName = app.utils.getPropertyValue(data, "firstName");
if (firstName !== null) {
this.edtContactPersonFirstname.setDataValue(firstName);
}
//
var name1 = app.utils.getPropertyValue(data, "name1");
if (name1 !== null) {
this.edtContactPersonName.setDataValue(name1);
}
//
var phoneFmt = app.utils.getPropertyValue(data, "phoneFmt");
if (phoneFmt !== null) {
this.edtContactPersonPhone.setDataValue(phoneFmt);
}
//
var email = app.utils.getPropertyValue(data, "email");
if (email !== null) {
this.edtContactPersonMail.setDataValue(email);
}
}
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cboContactPartnerIdChange() failed: " + e.toString(), e);
}
},
cbxNoContactPartnerChange: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
this.controller.setByQuickSetup("ContactPartner", !inSender.getChecked(), true);
//
this.controller.enableContainer(inSender.getChecked(), this.pnlContactPerson, this.cboContactPartnerId);
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cbxNoContactPartnerChange() failed: " + e.toString(), e);
}
},
cbxNoDatasheetChange: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
this.controller.setByQuickSetup("FactoryData", !inSender.getChecked(), true);
//
this.controller.enableContainer(inSender.getChecked(), this.pnlDatasheetLayout, this.cboDatasheetId);
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".cbxNoDatasheetChange() failed: " + e.toString(), e);
}
},
addFactoryError: function(inSender, inError) {
try {
console.debug('Start addFactoryError');
var errMsg = this.getDictionaryItem("ERROR_MSG_ERROR_BY_ADD_DATA") + inError.message;
app.toastError(errMsg);
console.debug('End addFactoryError');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".addFactoryError() failed: " + e.toString(), e);
}
},
addFactoryResult: function(inSender, inDeprecated) {
try {
console.debug('Start addFactoryResult');
console.debug('End addFactoryResult');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".addFactoryResult() failed: " + e.toString(), e);
}
},
refreshOnAddServiceSuccess: function() {
try {
app.dummyServiceVar.doRequest();
this.navCallFactory.update();
if (!this.controller.clearWizard(0)) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_CLEARWIZARD");
}
/*
Wenn Ergebnismengen nach dem erfolgreichen Einfügen von Servicedaten aktualisiert werden sollen dann hier durchführen
if (this.<serviceVariable>.canUpdate()) {
this.<serviceVariable>.update();
} else {
throw this.getDictionaryItem("ERROR_MSG_BY_REFRESH_<serviceVariable-description>");
}
*/
app.dummyServiceVar.doResult();
return true;
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".refreshOnAddServiceSuccess() failed: " + e.toString(), e, -1);
app.dummyServiceVar.doResult();
return false;
}
},
addFactorySuccess: function(inSender, inDeprecated) {
try {
console.debug('Start addFactorySuccess');
/* varResultByInsert muss von dem Aufruf der Testprocedure auf den AddFactory-Service umgelegt werden */
console.debug('Success: ' + this.varResultByInsert.getValue('success'));
console.debug('Code: ' + this.varResultByInsert.getValue('code'));
console.debug('Info: ' + this.varResultByInsert.getValue('info'));
var code = this.varResultByInsert.getValue('code');
var success = this.varResultByInsert.getValue('success');
if (!code) {
this.controller.infoByUnhandledCode(success);
} else {
var codeStr = this.varResultByInsert.getValue('info');
if (!codeStr) {
this.controller.infoByUnhandledCode(success);
} else {
var kindFound = codeStr.search(/kind/);
if (kindFound != -1) {
var codeObj = dojo.fromJson(codeStr);
switch (codeObj.kind) {
case 1:
/* Fehler mit einfacher Fehlermeldung */
dojo.publish(codeObj.publish, [codeObj]);
//
break;
case 2:
/* Fehler mit erweiterter Fehlermeldung */
dojo.publish(codeObj.publish, [codeObj]);
//
break;
case 4:
// case 4 und case 3 sollen den selben Code durchlaufen, daher kein code und kein break
case 3:
/* Daten erfolgreich übernommen */
dojo.publish(codeObj.publish, [codeObj]);
if (!this.refreshOnAddServiceSuccess()) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_REFRESHWIZARD");
}
//
break;
default:
//
break;
}
console.debug('Kind: ' + codeObj.kind + ' - Publish: ' + codeObj.publish + ' - Message: ' + codeObj.message);
} else {
this.controller.infoByUnhandledCode(success);
}
}
}
console.debug('End addFactorySuccess');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".addFactorySuccess() failed: " + e.toString(), e);
}
},
btnAddPersonClick: function(inSender) {
//code kommt noch
},
btnFindPersonClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000,  mode: 0, find: 'person', callback: 'onGetResultBySearch'}");
},
btnFindDataSheetClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000,  mode: 0, find: 'datasheet', callback: 'onGetResultBySearch'}");
},
btnAddDatasheetClick: function(inSender) {
//code kommt noch
},
btnAddAddressTypeClick: function(inSender) {
//code kommt noch
},
btnFindAddresstypeClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000,  mode: 0, find: 'addressType', callback: 'onGetResultBySearch'}");
},
btnFindContactTypeClick: function(inSender) {
//code kommt noch
},
btnFindAreaCodeClick: function(inSender) {
this.controller.showSearch(this, "{kind: 1000,  mode: 0, find: 'areaCode', callback: 'onGetResultBySearch'}");
},
btnAddContactTypeClick: function(inSender) {
//code kommt noch
},
btnAddAreaCodeClick: function(inSender) {
//code kommt noch
},
_end: 0
});

NewFactory.widgets = {
navCallFactory: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layFactory","targetProperty":"layer"}, {}]
}]
}]
}],
navCallFactoryData: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layDatasheet","targetProperty":"layer"}, {}]
}]
}]
}],
navCallAddress: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layAddress","targetProperty":"layer"}, {}]
}]
}]
}],
navCallContact: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layContact","targetProperty":"layer"}, {}]
}]
}]
}],
navCallBank: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layBank","targetProperty":"layer"}, {}]
}]
}]
}],
navCallInfo: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layInfo","targetProperty":"layer"}, {}]
}]
}]
}],
navCallSummery: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"laySummery","targetProperty":"layer"}, {}]
}]
}]
}],
navCallPhoto: ["wm.NavigationCall", {}, {}, {
input: ["wm.ServiceInput", {"type":"gotoLayerInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"layPhoto","targetProperty":"layer"}, {}]
}]
}]
}],
varTenantId: ["wm.Variable", {"type":"NumberData"}, {}],
srvVarContactPartnerLookUp: ["wm.ServiceVariable", {"autoUpdate":true,"inFlightBehavior":"dontExecute","loadingDialog":"","operation":"getLookupContactPartnerByTenant","service":"ZABonlineDB"}, {}, {
input: ["wm.ServiceInput", {"type":"getLookupContactPartnerByTenantInputs"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"varTenantId.dataValue","targetProperty":"TenantId"}, {}]
}]
}]
}],
varCodeByResult: ["wm.Variable", {"isList":true,"json":"[\n\t{\n\t\t\"name\": \"Gerke\", \n\t\t\"dataValue\": \"Alfred\"\n\t}, \n\t{\n\t\t\"name\": \"Gerke2\", \n\t\t\"dataValue\": \"Alfred2\"\n\t}, \n\t{\n\t\t\"name\": \"Gerke3\", \n\t\t\"dataValue\": \"Alfred3\"\n\t}\n]","type":"EntryData"}, {}],
varFilename: ["wm.Variable", {"type":"StringData"}, {}],
varResultByInsert: ["wm.Variable", {"dataSet":"","isList":true,"type":"de.zabonline.srv.Results.ProcResults"}, {}],
varUniqueFilename: ["wm.Variable", {"type":"StringData"}, {}],
varUploadPhoto: ["wm.Variable", {"type":"FileUploadDownload.WMFile"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"fileUpload.variable.name","targetProperty":"name"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"fileUpload.variable.path","targetProperty":"path"}, {}]
}]
}],
varUploadPhotoResponse: ["wm.Variable", {"type":"com.wavemaker.runtime.server.FileUploadResponse"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"fileUpload.variable.error","targetProperty":"error"}, {}]
}]
}],
addFactory: ["wm.ServiceVariable", {"inFlightBehavior":"dontExecute","loadingDialog":"","operation":"sampleJavaOperation","service":"FactoryService"}, {"onError":"addFactoryError","onResult":"addFactoryResult","onSuccess":"addFactorySuccess"}, {
input: ["wm.ServiceInput", {"type":"sampleJavaOperationInputs"}, {}]
}],
lbxMain: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}, {
wizNewFactory: ["wm.WizardLayers", {"defaultLayer":0}, {"onCancelClick":"wizNewFactoryCancelClick","onDoneClick":"wizNewFactoryDoneClick","oncanchange":"wizNewFactoryCanchange","onchange":"wizNewFactoryChange"}, {
layFactory: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Betrieb","horizontalAlign":"left","padding":"5","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlFactoryLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
pnlFactoryBasicData: ["wm.FancyPanel", {"height":"156px","title":"Betrieb"}, {}, {
pnlIdentBasisData: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
edtFactoryNumber: ["wm.Text", {"caption":"Betriebsnummer","captionSize":"110px","dataValue":undefined,"displayValue":""}, {}],
edtFactory: ["wm.Text", {"caption":"Betrieb","captionSize":"110px","dataValue":undefined,"displayValue":"","required":true,"width":"400px"}, {}],
edtDescription1: ["wm.Text", {"caption":"Beschreibung","captionSize":"110px","dataValue":undefined,"displayValue":"","width":"640px"}, {}],
edtDescription2: ["wm.Text", {"caption":" ","captionSize":"110px","dataValue":undefined,"displayValue":"","width":"640px"}, {}],
edtDescription3: ["wm.Text", {"caption":" ","captionSize":"110px","dataValue":undefined,"displayValue":"","width":"640px"}, {}]
}]
}],
pnlNoContactPartner: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
cbxNoContactPartner: ["wm.Checkbox", {"caption":"kein Ansprechpartner","captionAlign":"left","captionPosition":"right","captionSize":"150px","displayValue":false,"emptyValue":"false","height":"100%","width":"160px"}, {"onchange":"cbxNoContactPartnerChange"}]
}],
pnlContactPerson: ["wm.FancyPanel", {"freeze":false,"title":"Ansprechpartner"}, {}, {
pnlBasisContactPersonData: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
cboContactPartnerIdPanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboContactPartnerId: ["wm.SelectMenu", {"allowNone":true,"caption":"Ansprechpartner","captionSize":"110px","dataField":"c0","dataType":"com.zabonlinedb.data.output.GetLookupContactPartnerByTenantRtnType","displayField":"contactPartner","displayValue":"","emptyValue":"null"}, {"onchange":"cboContactPartnerIdChange"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"srvVarContactPartnerLookUp","targetProperty":"dataSet"}, {}]
}]
}],
btnFindPerson: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindPersonClick"}],
btnAddPerson: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddPersonClick"}]
}],
edtContactPersonFirstname: ["wm.Text", {"caption":"Vorname","captionSize":"110px","dataValue":undefined,"displayValue":""}, {}],
edtContactPersonName: ["wm.Text", {"caption":"Name","captionSize":"110px","dataValue":undefined,"displayValue":"","required":true}, {}],
edtContactPersonPhone: ["wm.Text", {"caption":"Telefon","captionSize":"110px","dataValue":undefined,"displayValue":""}, {}],
edtContactPersonMail: ["wm.Text", {"caption":"eMail","captionSize":"110px","dataValue":undefined,"displayValue":""}, {}]
}]
}]
}]
}],
layDatasheet: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Betriebsdaten","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlNoDatasheet: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
cbxNoDatasheet: ["wm.Checkbox", {"caption":"kein Datenblatt","captionAlign":"left","captionPosition":"right","captionSize":"150px","displayValue":false,"emptyValue":"false","height":"100%","width":"150px"}, {"onchange":"cbxNoDatasheetChange"}]
}],
pnlDatasheetLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
pnlFactoryDatasheet: ["wm.FancyPanel", {"freeze":false,"height":"107px","title":"Datenblatt"}, {}, {
pnlFactoryDataIdentDetail: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
cboDatasheetIdPanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboDatasheetId: ["wm.SelectMenu", {"allowNone":true,"caption":"Datenblatt","dataSet":"","dataType":"com.zabonlinedb.data.output.GetLookupPersonByMarriageRtnType","displayValue":"","emptyValue":"null"}, {"onchange":"cboDatasheetIdChange"}],
btnFindDatasheet: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindDataSheetClick"}],
btnAddDatasheet: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddDatasheetClick"}]
}],
edtDatasheetShortDesc: ["wm.Text", {"caption":"Name","dataValue":undefined,"displayValue":""}, {}],
edtDatasheetLongDesc: ["wm.Text", {"caption":"Beschreibung","dataValue":undefined,"displayValue":"","width":"640px"}, {}]
}]
}],
pnlFactoryDetailData: ["wm.FancyPanel", {"title":"Betriebsdaten"}, {}]
}]
}],
layAddress: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Adressdaten","horizontalAlign":"left","margin":"5","padding":"5","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlNoAddressData: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
cbxNoAddressData: ["wm.Checkbox", {"caption":"keine Adressdaten","captionAlign":"left","captionPosition":"right","captionSize":"150px","displayValue":false,"emptyValue":"false","height":"100%","width":"150px"}, {"onchange":"cbxNoAddressDataChange"}]
}],
pnlAddressLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlBasicAddressData: ["wm.FancyPanel", {"freeze":false,"title":"Adresse"}, {}, {
cboAddressTypePanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"405px"}, {}, {
cboAddressType: ["wm.SelectMenu", {"caption":"Addresstyp","dataField":"id","dataType":"com.zabonlinedb.data.output.GetLookupAddressTypeByCountryRtnType","displayField":"caption","displayValue":""}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"app.addressTypeData","targetProperty":"dataSet"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"app.addressTypeData.id","targetProperty":"dataValue"}, {}]
}]
}],
btnFindAddressType: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindAddresstypeClick"}],
btnAddAddressType: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddAddressTypeClick"}]
}],
edtDistrict: ["wm.Text", {"caption":"Ortsteil","dataValue":undefined,"displayValue":""}, {}],
pnlFmtCityData: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
edtZIPCode: ["wm.Text", {"caption":"PLZ","dataValue":undefined,"displayValue":"","regExp":"","required":true,"width":"178px"}, {}],
edtCity: ["wm.Text", {"caption":"Stadt","captionSize":"50px","dataValue":undefined,"displayValue":"","required":true,"width":"221px"}, {}]
}],
edtPostOffice: ["wm.Text", {"caption":"Postfach","dataValue":undefined,"displayValue":""}, {}],
pnlFmtStreetData: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
edtStreet: ["wm.Text", {"caption":"Straße","dataValue":undefined,"displayValue":"","required":true}, {}],
edtStreetAddressFrom: ["wm.Text", {"caption":"von","captionSize":"50px","dataValue":undefined,"displayValue":"","required":true,"width":"100px"}, {}],
edtStreetAddressTo: ["wm.Text", {"caption":"bis","captionSize":"50px","dataValue":undefined,"displayValue":"","width":"100px"}, {}]
}],
cbxIsPostOfficeAddress: ["wm.Checkbox", {"caption":"Postanschrift","displayValue":false,"emptyValue":"false"}, {}],
cbxIsPrivateAddress: ["wm.Checkbox", {"caption":"Privat","displayValue":false,"emptyValue":"false"}, {}]
}]
}]
}],
layContact: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Kontaktdaten","horizontalAlign":"left","margin":"5","padding":"5","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlNoContactData: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
cbxNoContactData: ["wm.Checkbox", {"caption":"keine Kontaktdaten","captionAlign":"left","captionPosition":"right","captionSize":"150px","displayValue":false,"emptyValue":"false","height":"100%","width":"150px"}, {"onchange":"cbxNoContactDataChange"}]
}],
pnlContactLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlBasicContactData: ["wm.FancyPanel", {"title":"Kontakt"}, {}, {
cboContactTypePanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboContactType: ["wm.SelectMenu", {"caption":"Kontakttyp","dataField":"id","dataType":"com.zabonlinedb.data.output.GetLookupContactTypeByCountryRtnType","displayField":"caption","displayValue":""}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"app.contactTypeData","targetProperty":"dataSet"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"app.contactTypeData.id","targetProperty":"dataValue"}, {}]
}]
}],
btnFindContactType: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindContactTypeClick"}],
btnAddContactType: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddContactTypeClick"}]
}],
cboAreaCodePanel: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"380px"}, {}, {
cboAreaCode: ["wm.SelectMenu", {"allowNone":true,"caption":"Gebietscode","dataField":"areacode","dataType":"com.zabonlinedb.data.output.GetLookupAreaCodeRtnType","displayField":"areacode","displayValue":""}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"app.areaCodeData","targetProperty":"dataSet"}, {}],
wire1: ["wm.Wire", {"expression":undefined,"source":"app.areaCodeData.areacode","targetProperty":"dataValue"}, {}]
}]
}],
btnFindAreaCode: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":48,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnFindAreaCodeClick"}],
btnAddAreaCode: ["wm.Button", {"caption":undefined,"height":"100%","imageIndex":1,"imageList":"app.silkIconList","margin":"1","padding":"1","styles":{"fontStyle":"","fontSize":"12px","fontWeight":""},"width":"35px"}, {"onclick":"btnAddAreaCodeClick"}]
}],
edtTel: ["wm.Text", {"caption":"Telefon","dataValue":undefined,"displayValue":""}, {}],
edtFax: ["wm.Text", {"caption":"Fax","dataValue":undefined,"displayValue":""}, {}],
edtWWW: ["wm.Text", {"caption":"www","dataValue":undefined,"displayValue":""}, {}],
edtEmail: ["wm.Text", {"caption":"eMail","dataValue":undefined,"displayValue":""}, {}],
edtSkype: ["wm.Text", {"caption":"Skype","dataValue":undefined,"displayValue":""}, {}],
edtMessanger: ["wm.Text", {"caption":"Messanger","dataValue":undefined,"displayValue":""}, {}]
}]
}]
}],
layBank: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Bankinformationen","horizontalAlign":"left","margin":"5","padding":"5","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlNoBankInfo: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
cbxNoBankInfo: ["wm.Checkbox", {"caption":"keine Bankinformationen","captionAlign":"left","captionPosition":"right","captionSize":"170px","displayValue":false,"emptyValue":"false","height":"100%","width":"170px"}, {"onchange":"cbxNoBankInfoChange"}]
}],
pnlBankLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlBasicBankData: ["wm.FancyPanel", {"title":"Bank"}, {}, {
edtDepositor: ["wm.Text", {"caption":"Kontoinhaber","dataValue":undefined,"displayValue":"","required":true}, {}],
edtKTO: ["wm.Text", {"caption":"Kontonummer","dataValue":undefined,"displayValue":"","required":true}, {}],
edtBLZ: ["wm.Text", {"caption":"Bankleitzahl","dataValue":undefined,"displayValue":"","required":true}, {}],
edtIBAN: ["wm.Text", {"caption":"IBAN","dataValue":undefined,"displayValue":""}, {}],
edtBIC: ["wm.Text", {"caption":"BIC","dataValue":undefined,"displayValue":""}, {}]
}]
}]
}],
layInfo: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Information","horizontalAlign":"left","margin":"5","padding":"5","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlNoInfo: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
cbxNoInfo: ["wm.Checkbox", {"caption":"keine Informationen","captionAlign":"left","captionPosition":"right","captionSize":"170px","displayValue":false,"emptyValue":"false","height":"100%","width":"170px"}, {"onchange":"cbxNoInfoChange"}]
}],
pnlInfoLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlFreeText: ["wm.FancyPanel", {"title":"Freitext"}, {}, {
edtDescription: ["wm.RichText", {"height":"100%"}, {}]
}]
}]
}],
layPhoto: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Bildmaterial","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlNoPhoto: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
cbxNoPhoto: ["wm.Checkbox", {"caption":"kein Bildmaterial","captionAlign":"left","captionPosition":"right","captionSize":"170px","displayValue":false,"emptyValue":"false","height":"100%","width":"170px"}, {"onchange":"cbxNoPhotoChange"}]
}],
pnlPhotoLayout: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
pnlChoosePhoto: ["wm.FancyPanel", {"innerHorizontalAlign":"center","title":"Datei auswählen"}, {}, {
picPhoto: ["wm.Picture", {"aspect":"v","height":"213px","margin":"5,0,0,0","source":"resources/images/logos/symbol_questionmark.png","width":"165px"}, {}],
fileUpload: ["wm.DojoFileUpload", {"buttonCaption":"Laden...","height":"30px","layoutKind":"top-to-bottom","padding":"5,0,0,0","useList":false,"width":"159px"}, {"onSuccess":"fileUploadSuccess"}, {
input: ["wm.ServiceInput", {"type":"uploadFileInputs"}, {}]
}],
lblPhotoName: ["wm.Label", {"margin":"5,0,0,0","padding":"4","width":"159px"}, {}, {
format: ["wm.DataFormatter", {}, {}],
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"\"Datei: \" + ${varFilename.dataValue}","targetProperty":"caption"}, {}]
}]
}],
lblResponseInfo: ["wm.Label", {"_classes":{"domNode":["wm_FontColor_BrightRed"]},"height":"84px","padding":"4","singleLine":false,"width":"159px"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"varUploadPhotoResponse.error","targetProperty":"caption"}, {}]
}]
}]
}]
}]
}],
laySummery: ["wm.Layer", {"border":"1","borderColor":"#333333","caption":"Zusammenfassen","horizontalAlign":"left","margin":"5","padding":"5","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
pnlSummery: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
pnlSummeryDetailTop: ["wm.Panel", {"height":"90%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
pnlFactorySumAll: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"25%"}, {}, {
pnlSummeryDetailFactory: ["wm.FancyPanel", {"title":"Betrieb"}, {}, {
btnGotoFactory: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallFactory"}],
lblSumInfoFactoryNumber: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoFactory: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoDescription1: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}, {
format: ["wm.DataFormatter", {}, {}]
}],
lblSumInfoDescription2: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoDescription3: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoContactPartner: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoCPFirstname: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoCPName: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoCPTel: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoCPEmail: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}],
pnlSummeryDetailFactoryData: ["wm.FancyPanel", {"title":"Betriebsdaten"}, {}, {
btnGotoFactoryData: ["wm.Button", {"caption":"Ändern","margin":"4","mobileHeight":"32%","width":"100%"}, {"onclick":"navCallFactoryData"}],
lblSumInfoDatasheet: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoDatasheetName: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoDatasheetDesc: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}]
}],
pnlSummeryDetailAddress: ["wm.FancyPanel", {"title":"Adresse","width":"25%"}, {}, {
btnGotoAddress: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallAddress"}],
lblSumInfoAddressType: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoDistrict: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoZIPCode: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoCity: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoPostOffice: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoStreet: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoStreetAddressFrom: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoStreetAddressTo: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoIsPostOfficeAddress: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfosPrivateAddress: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}],
pnlSummeryDetailContact: ["wm.FancyPanel", {"title":"Kontakt","width":"25%"}, {}, {
btnGotoContact: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallContact"}],
lblSumInfoContactType: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoAreaCode: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoTel: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoFax: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoWWW: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoEmail: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoSkype: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoMessanger: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}],
pnlSummeryDetailBank: ["wm.FancyPanel", {"title":"Bank","width":"25%"}, {}, {
btnGotoBank: ["wm.Button", {"caption":"Ändern","margin":"4","width":"100%"}, {"onclick":"navCallBank"}],
lblSumInfoDepositor: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoKTO: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoBLZ: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoIBAN: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}],
lblSumInfoBIC: ["wm.Label", {"caption":"","height":"20px","padding":"4","width":"100%"}, {}]
}]
}],
pnlSummeryDetailBottom: ["wm.Panel", {"height":"10%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
btnAddAddressBookItem: ["wm.Button", {"caption":"Daten aufnehmen","margin":"4","width":"100%"}, {"onclick":"btnAddAddressBookItemClick"}]
}]
}]
}]
}]
}]
};

NewFactory.prototype._cssText = '';
NewFactory.prototype._htmlText = '';