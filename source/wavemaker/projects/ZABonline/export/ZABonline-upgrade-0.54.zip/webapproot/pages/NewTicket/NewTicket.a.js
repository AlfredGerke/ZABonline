dojo.declare("NewTicket", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
_end: 0
});

NewTicket.widgets = {
layoutBox1: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}]
};

NewTicket.prototype._cssText = '';
NewTicket.prototype._htmlText = '';