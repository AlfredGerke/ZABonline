dojo.declare("ShowAbout", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
_end: 0
});

ShowAbout.widgets = {
lbxMain: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}]
};

ShowAbout.prototype._cssText = '';
ShowAbout.prototype._htmlText = '';