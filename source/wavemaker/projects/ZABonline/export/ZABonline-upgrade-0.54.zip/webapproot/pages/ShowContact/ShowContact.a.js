dojo.declare("ShowContact", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
_end: 0
});

ShowContact.widgets = {
lbxMain: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}]
};

ShowContact.prototype._cssText = '';
ShowContact.prototype._htmlText = '';