dojo.declare("NewTable", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
_end: 0
});

NewTable.widgets = {
lbxMain: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}]
};

NewTable.prototype._cssText = '';
NewTable.prototype._htmlText = '';