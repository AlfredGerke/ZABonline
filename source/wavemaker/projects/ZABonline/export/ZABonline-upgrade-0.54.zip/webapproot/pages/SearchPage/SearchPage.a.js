dojo.declare("SearchPage", wm.Page, {
"i18n": true,
"preferredDevice": "desktop",
onResultByNewRedording: function() {},
onSuccessByNewRecording: function(success) {},
start: function() {
try {
console.debug('SearchPage.start: start');
this.controller = new SearchPageCtrl(app, this);
console.debug('SearchPage.start: end');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".start() failed: " + e.toString(), e);
}
},
onShow: function() {
try {
console.debug('SearchPage.onShow: start');
app.dlgLoading.setParameter(app.dummyServiceVar, this.lbxMain);
if (!this.controller) {
app.alert(this.getDictionaryItem("ERROR_MSG_BY_UNKNOWN_CONTROLLER"));
} else {
app.dummyServiceVar.doRequest();
if (!this.controller.loadLookupData()) {
throw this.getDictionaryItem("ERROR_MSG_BY_CONTROLLER_LOOUPDATA");
}
app.dummyServiceVar.doResult();
}
console.debug('SearchPage.onShow: end');
} catch (e) {
app.dummyServiceVar.doResult();
this.controller.handleExceptionByCtrl(this.name + ".onShow() failed: " + e.toString(), e, 1);
app.closeSearchPage(this.controller);
}
},
onStart: function(inPage) {
try {
console.debug('SearchPage.onStart: Begin');
console.debug('SearchPage.onStart: End');
} catch (e) {
this.controller.handleExceptionByCtrl(this.name + ".onStart() failed: " + e.toString(), e);
}
},
_end: 0
});

SearchPage.widgets = {
startSearchByDB: ["wm.ServiceVariable", {"inFlightBehavior":"executeLast","operation":"startSearchByDb","service":"Miscellaneous"}, {}, {
input: ["wm.ServiceInput", {"type":"startSearchByDbInputs"}, {}]
}],
varResultBySearch: ["wm.Variable", {"isList":true,"type":"de.zabonline.srv.Results.ProcResults"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"startSearchByDB","targetProperty":"dataSet"}, {}]
}]
}],
varTenantId: ["wm.Variable", {"type":"NumberData"}, {}],
lbxMain: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}, {
pnlTop: ["wm.Panel", {"height":"48px","horizontalAlign":"left","verticalAlign":"middle","width":"100%"}, {}, {
edtExpression: ["wm.Text", {"caption":"Suchen","dataValue":undefined,"displayValue":"","helpText":"Suche starten","placeHolder":"Suchwort eingeben","width":"300%"}, {}]
}],
pnlDetail: ["wm.Panel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
gridResult: ["wm.DojoGrid", {"height":"100%","localizationStructure":{},"minDesktopHeight":60,"singleClickEdit":true}, {}]
}],
pnlBottum: ["wm.Panel", {"height":"36px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
navResult: ["wm.DataNavigator", {"border":"0","height":"33px","width":"100%"}, {}]
}]
}]
};

SearchPage.prototype._cssText = '';
SearchPage.prototype._htmlText = '';