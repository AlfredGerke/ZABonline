FollowUp.widgets = {
	lbxMain: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}]
}