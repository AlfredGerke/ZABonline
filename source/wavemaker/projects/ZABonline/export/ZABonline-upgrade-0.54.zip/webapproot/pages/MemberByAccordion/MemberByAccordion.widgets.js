MemberByAccordion.widgets = {
	lbxMain: ["wm.Layout", {"borderColor":"#ffffff","horizontalAlign":"center","margin":"0","styles":{"textDecoration":""},"verticalAlign":"top"}, {}, {
		picAddressBook: ["wm.Picture", {"_classes":{"domNode":["imgByAccording"]},"border":"1","borderColor":"","height":"64px","imageIndex":0,"source":"resources/images/buttons/ByMemberInAccordion/address_book.png","width":"64px"}, {}],
		lblAddressBook: ["wm.Label", {"_classes":{"domNode":["lblByAccordion"]},"align":"center","autoSizeWidth":true,"caption":"Adressbuch","margin":"4","padding":"","styles":{"textDecoration":""},"width":"76px"}, {}],
		picFactory: ["wm.Picture", {"_classes":{"domNode":["imgByAccording"]},"border":"1","borderColor":"","height":"64px","imageIndex":0,"source":"resources/images/buttons/ByMemberInAccordion/office_building.png","width":"64px"}, {}],
		lblFactory: ["wm.Label", {"_classes":{"domNode":["lblByAccordion"]},"align":"center","autoSizeWidth":true,"caption":"Betriebsverwaltung","margin":"4","padding":"","width":"120px"}, {}],
		picMembers: ["wm.Picture", {"_classes":{"domNode":["imgByAccording"]},"border":"1","borderColor":"","height":"64px","imageIndex":0,"source":"resources/images/buttons/ByMemberInAccordion/businesspeople2.png","width":"64px"}, {}],
		lblMembers: ["wm.Label", {"_classes":{"domNode":["lblByAccordion"]},"align":"center","autoSizeWidth":true,"caption":"Mitglieder","margin":"4","padding":"","width":"65px"}, {}]
	}]
}