dojo.declare("NewDatasheet", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
_end: 0
});

NewDatasheet.widgets = {
lbxMain: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}]
};

NewDatasheet.prototype._cssText = '';
NewDatasheet.prototype._htmlText = '';