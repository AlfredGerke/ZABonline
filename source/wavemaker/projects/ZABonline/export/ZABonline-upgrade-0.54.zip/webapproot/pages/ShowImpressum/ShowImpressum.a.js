dojo.declare("ShowImpressum", wm.Page, {
start: function() {
},
"preferredDevice": "desktop",
_end: 0
});

ShowImpressum.widgets = {
lbxMain: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}]
};

ShowImpressum.prototype._cssText = '';
ShowImpressum.prototype._htmlText = '';