{
"ALERT_LOGIN_FAILED": "Anmeldung fehlgeschlagen!",
"CAPTION_LOGIN_FAILED": "Anmeldung fehlgeschlagen!"
}