{
  "ERROR_MSG_BY_UNKNOWN_CONTROLLER": "",
  "ERROR_MSG_BY_CONTROLLER_LOOUPDATA": "Fehler aus dem Modul: Lookup-Daten nicht vollst&auml;ndig!",
  "ERROR_MSG_BY_CONTROLLER_NO_KIND_FOUND": "Kein Suchtyp definiert!"
}