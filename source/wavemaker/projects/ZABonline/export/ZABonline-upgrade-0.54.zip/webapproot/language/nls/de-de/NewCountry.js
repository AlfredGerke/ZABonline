{
  "ADD_NEWCOUNTRYCODES_SUCCEEDED": "",
  "INSERT_BY_NEWCOUNTRYCODES_FAILD": "",
  "CAPTION_CATALOG": "L&auml;nderkennung",
  "REG_EXPR_NO_EXPR": ".*",
  "ERROR_MSG_BY_INIT_SELECTMENU": "Einige Auswahllisten besitzen unter Umst&auml;nden keine Startwerte!",
  "ERROR_MSG_BY_CONTROLLER_NO_KIND_FOUND": "Kein Verarbeitungstyp definiert!",
  "ERROR_MSG_ERROR_BY_ADD_COUNTRYCODES": "Der Service wurde mit einem Fehler abgebrochen: ",
  "ERROR_MSG_BY_CONTROLLER_CLEARWIZARD": "Fehler aus dem Modul: Daten im Assistenten nicht vollst&auml;ndig zur&uuml;ck gesetzt!",
  "ERROR_MSG_BY_CONTROLLER_REFRESHWIZARD": "Fehler beim Aktualisieren des Assistenten!",
  "ERROR_MSG_BY_UNKNOWN_CONTROLLER": "Kein Zugriff auf das Modul m&ouml;glich!",
  "NO_GRANT_FOR_ADD_COUNTRYCODES": "Keine Autorisierung f&uuml;r diese Funktion!",
  "ERROR_MSG_ADD_COUNTRYCODES_NO_SUCCESS_BY_EXECUTE": "Daten konnten nicht &uuml;bernommen werden. Bitte noch einmal versuchen!",
  "ERROR_MSG_BY_CONTROLLER_LOOUPDATA": "Fehler aus dem Modul: Lookup-Daten nicht vollst&auml;ndig!",
  "REG_EXPR_COUNTRY_CODE": ".*",
  "REG_EXPR_CURRENCE_CODE": ".*",
  "REG_EXPR_AREA_CODE": ".*"
}