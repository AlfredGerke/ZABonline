{
  "CAPTION_ADDCATALOG_TITLE_AREA_CODE": "Neuaufnahme Gebietskennung",
  "CAPTION_ADDCATALOG_TITLE_SALUTATION": "Neuaufnahme Anrede",
  "CAPTION_ADDCATALOG_TITLE_TITLE": "Neuaufnahme Titel",
  "CAPTION_ADDCATALOG_TITLE_ADDRESS_TYPE": "Neuaufnahme Adresstyp",
  "CAPTION_ADDCATALOG_TITLE_CONTACT_TYPE": "Neuaufname Konakttyp",
  "CAPTION_ADDCOUNTRY_TITLE": "L&auml;nderkennung",
  "NO_GRANT_FOR_ADD_COUNTRYCODES": "Keine Autorisierung f&uuml;r diese Funktion!",
  "NO_GRANT_FOR_ADD_ROLE": "Bearbeiten von Berechtigungsdaten nicht erlaubt!",
  "NO_GRANT_FOR_START_FIND": "Erstellen einer Suchanfrage nicht erlaubt!",
  "NO_GRANT_FOR_ADD_USER": "Bearbeiten von Benutzerdaten nicht erlaubt!",
  "NO_GRANT_FOR_ADD_MEMBER": "Bearbeiten von Mitgliederdaten nicht erlaubt!",
  "NO_GRANT_FOR_ADD_CATALOGITEM": "Bearbeiten von Katalogen nicht erlaubt!",
  "CANCEL_PROCESS_BY_SESSIONMANAGEMENT": "Vorgang durch Sitzungsverwaltung abgebrochen!",
  "CONFIRM_DLG_TITLE": "Auswahl best&auml;tigen",
  "NO_GRANT_FOR_MISC": "Anwenden von Verschiedenem nicht erlaubt!",
  "NO_GRANT_FOR_ADD_FILERESOURCE": "Einf�gen von Dateiquellen nicht erlaubt",
  "ERROR_MSG_EROOR_BY_CHECKGRANT_SERVICE": "Keine Autorisierung f&uuml;r diese Funktion!"
}